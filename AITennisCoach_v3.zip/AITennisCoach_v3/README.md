# AI Tennis Coach — version 3

R Shiny app that compares a student's tennis stroke with a professional's using
MediaPipe Tasks **PoseLandmarker** 3D world landmarks.

## What is new in version 3

| Feature | What it does |
|---|---|
| **Six strokes** | Forehand, two-handed backhand, one-handed backhand, slice backhand, volley and serve. Each has its own contact rule (serve contact must be above the head; two-handed strokes track both hands), its own analysis window and its own coaching rules (`bin/strokes.py`). |
| **Whole-stroke measures** | Deepest knee bend before contact, shoulder turn against the hips, non-hitting/toss arm height, contact height, swing path rise (low-to-high vs high-to-low), take-back length and follow-through length. Lengths are in trunk lengths, so body size does not matter. |
| **Better AI coaching** | Rules rank the biggest differences and list what already matches the professional. The AI coach gets the stroke's technical checkpoints, the student's level and goal, every measurement with its meaning, and must answer in a fixed structure: summary, strengths, up to three priorities (numbers, why it matters, feel cue, drill, how to check on video), a 20-minute practice plan and caveats. Follow-up questions use the same context. |
| **Downloads** | HTML report (print to PDF), CSV of all measures, and a ZIP with the report, CSVs, angle curves, annotated videos, contact frames and the side-by-side video. |
| **Sliders under each video** | Frame slider, ±1 frame buttons, play/pause and *Contact* under every video, plus a **linked slider** that moves both videos to matching moments of the two strokes (from the DTW alignment) and a *Both at contact* button. |
| **Equal video windows** | Both videos sit side by side in identical square windows; annotated videos are letterboxed to 720×720 so neither player is stretched. A synchronised side-by-side video is also produced. |
| **Injury prevention & fitness** | A second AI button writes an injury-prevention and fitness plan for the student's age group and level: how the stroke loads the body (kinetic chain, eccentric braking, which tendons and joints are stressed), what the measurements suggest about load, a RAMP warm-up, prevention exercises with the physiological reason for each, a weekly plan, recovery and load management, and warning signs for seeing a physiotherapist. Grounded in per-stroke sports-medicine notes (`strokes.BODY_LOAD`). |
| **Still-frame coaching** | Still-frame comparisons get their own AI technique advice, injury/fitness advice and downloadable report; you say which phase the frames show (contact, preparation or follow-through). |
| **English or Chinese** | Choose the advice language. All AI advice, and the report headings, follow the choice. |
| **Slow motion** | Windows are sized from the swing itself, so slow-motion clips work; a speed setting per video converts durations to real time. |

## Installation (Mac / RStudio)

1. Optional but recommended: `brew install ffmpeg` (re-encodes annotated videos so browsers play them).
2. Unzip, open the folder in RStudio, choose **Session → Restart R**.
3. Run `source('setup.R')` once. It creates the `aitenniscoach` virtualenv (Python 3.11),
   installs MediaPipe 1.1.1, OpenCV, NumPy, requests and pytest, and downloads the model
   to `models/pose_landmarker_heavy.task`.
   If the download fails, save this file there manually:
   https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task
4. **Restart R**, then `shiny::runApp('.')`.

`OPENAI_API_KEY` is needed only for the AI advice buttons (set it in `~/.Renviron`).

## Usage

1. Choose the **stroke**. Upload the professional and student videos, set each player's **hand**
   (automatic detection is available but setting it is more reliable) and, for slow-motion clips, the speed.
   Uploaded videos appear straight away in the Motion tab.
2. **Analyse and compare**. You get the two annotated videos with their own sliders, the linked
   slider, a synchronised side-by-side video, whole-stroke measures, angles at contact and a plot
   of any angle through the stroke.
3. **Still frames** (optional): extract frames, pick one of each, compare. Quicker, but the
   two frames may not be the same moment of the stroke.
4. **Reliability check**: shows how much each angle moves when the same frame is re-detected.
5. **Coaching tab**: ranked findings and strengths, then AI advice (set the student's level and goal
   first) and follow-up questions.
6. **Downloads**: report, CSV or the full ZIP.

## The mathematics

* **Angles** come from normalised dot products of 3D joint vectors. They are unchanged by
  translation, uniform scaling and rotation, because a rotation Q satisfies QᵀQ = I and so
  preserves dot products.
* **Reflections also satisfy QᵀQ = I**, so angles alone cannot tell a left-hander from a
  mirrored right-hander.
* **Chirality**: with u = right shoulder − left shoulder, v = trunk axis and n = nose direction,
  the sign of the triple product (u × v)·n = det[u; v; n] is kept by rotations (det +1) and
  flipped by reflections (det −1). A left/right **label swap** also flips it (u → −u), so a
  mismatch between the two players reveals a mirrored video or a mislabelled skeleton.
* **Mirroring** a left-hander means reflecting the geometry *and* swapping labels. Two flips
  cancel, so the result is again a correctly labelled body with the same chirality.
* **Hip–shoulder separation** is a signed angle in the horizontal plane; its sign comes from a
  triple product with the vertical, so it flips under reflection while its size does not.
* **Contact** is estimated as the frame of peak hitting-wrist speed relative to the hips, after a
  3-frame running median removes one-frame tracking glitches.
* **Hitting arm** (when set to automatic) is the wrist with the higher robust peak speed (95th
  percentile of de-spiked speed). If the two wrists' peaks are within 30% of each other the app warns
  that the guess is uncertain; in a forehand the non-hitting arm also moves fast, so set the arm
  manually whenever you know it.
* **Frame-by-frame label swaps** are found by **movement continuity**: a real body moves only a little
  between frames, so if every left landmark suddenly sits where the right one was, the labels were
  swapped. A two-state Viterbi path chooses, for each frame, the labelling with the least total movement.
  (Version 3.0 used the frame-by-frame triple product instead. That was a mistake: when a player turns
  the head about 80 degrees or more to watch the ball, as at contact, the nose direction swings into the
  shoulder plane and the triple product changes sign without any labelling error. The swaps it then made
  moved the contact frame. A regression test now covers this.)
* The triple product is still used to compare the two players, but only when it is clearly non-zero
  (normalised value above 0.3), so a turned head cannot trigger it.
* **DTW** finds the monotone matching of the two angle sequences (z-scored per joint) with the
  least total distance, so a slower swing is compared phase by phase, not clock time.

## Tests

```
~/.virtualenvs/aitenniscoach/bin/python -m pytest tests      # or: python tests/test_geometry.py
```

The tests need only NumPy. They check rotation, scaling and translation invariance, that
reflections preserve angles but flip chirality, that label swaps flip chirality, that
mirroring twice is the identity, smoothing, gap filling, contact and hitting-arm detection,
that DTW recovers a known time warp, that stroke windows scale with slow motion, that serve contact is
taken above the head, that the swing-path measure separates topspin from slice, that the sync map is
monotone and matches the two contacts, and that every stroke rule refers to a real measure.

## Code map

* `app.R` — Shiny interface.
* `bin/geometry.py` — all the mathematics, pure NumPy (tested).
* `bin/pose_analysis.py` — MediaPipe detection, frame and video workflows, DTW comparison, reliability check.
* `bin/strokes.py` — the six strokes: contact rule, window, coaching checkpoints and rules.
* `bin/coaching.py` — applies the rules (findings and strengths) and builds the AI coach prompt.
* `bin/chatgpt_request.py` — optional OpenAI request.
* `tests/test_geometry.py` — invariance and algorithm tests.
* `setup.R` — environment and model setup.

## Limitations

* MediaPipe's 3D world coordinates are estimated from a single camera, so depth is the least
  reliable direction; film from a similar angle for both players.
* Contact from peak wrist speed is an approximation (peak racket-head speed is close to, not
  exactly at, impact).
* Rule thresholds are starting points chosen for this project, not established biomechanical norms;
  professional technique also varies (e.g. straight-arm vs bent-arm forehands).
* Each clip should contain one stroke. Camera angle matters: film both players from a similar position.
* The sample professional clip is low resolution (360×640), which lowers landmark accuracy.
  It is broadcast footage: fine for a private project, but do not redistribute it if the app
  is deployed publicly. Students' videos are personal data; get consent before sharing.
* Not an injury assessment.

## Testing status

Tested in the packaging environment: the 26 geometry tests pass; all six strokes were run end to end
on the sample videos with a **simulated** pose detector (analysis, contact, stroke window, measures,
rules, sync map, side-by-side H.264 video, AI prompt); and the slider/sync JavaScript was exercised
against simulated video elements.
**Not yet run:** real MediaPipe inference (the model could not be downloaded there) and the Shiny
interface itself (R was not available). Test both on the Mac with the sample videos.

## Troubleshooting

* *Missing model*: the app shows a red box with a **Download pose model** button and the exact folder it
  expects. The model is looked for in `models/` inside the app folder, then in `models/` of the working
  directory, then `~/models`.
* *Video does not play*: the app converts each upload into a browser-friendly copy (H.264, index at
  the start of the file) using FFmpeg. Phone videos often store the index at the end of the file, and
  iPhone videos may be HEVC, so without FFmpeg they may not play. Install it with `brew install ffmpeg`
  and restart R; the app also finds FFmpeg in `/opt/homebrew/bin` when RStudio cannot see your PATH.
  If videos still do not play in the RStudio window, click **Open in Browser** at the top of the app.
* *Python errors after updating*: restart R before `runApp`; never call `use_python()` after Python has started.
