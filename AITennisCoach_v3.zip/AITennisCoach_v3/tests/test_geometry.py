"""Tests for bin/geometry.py on synthetic skeletons.

Run from the project folder with either:
    python -m pytest tests
    python tests/test_geometry.py
No MediaPipe, camera or model file is needed.

These tests are the evidence for the mathematical claims in the project:
  * joint angles ignore translation, uniform scaling and rotation;
  * reflections ALSO preserve them (Q^T Q = I), so angles alone cannot see handedness;
  * the triple-product chirality flips under a reflection or a label swap,
    but not under rotation or a proper left/right mirror.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bin'))
import geometry as g  # noqa: E402

RNG = np.random.default_rng(42)


def skeleton():
    """A plausible standing right-hander in MediaPipe world coordinates
    (metres, hips at origin, y down, person facing the camera so -z is forward)."""
    w = np.zeros((33, 3))
    w[g.NOSE] = (0.0, -0.62, -0.10)
    for i in range(1, 11):                      # face points around the nose
        side = -1 if i in (4, 5, 6, 8, 10) else 1
        w[i] = (side * 0.03 * (1 + (i % 3)), -0.65, -0.08)
    w[g.L_SHOULDER], w[g.R_SHOULDER] = (0.19, -0.45, 0.06), (-0.19, -0.45, -0.06)  # shoulders turned
    w[g.L_ELBOW], w[g.R_ELBOW] = (0.28, -0.20, 0.02), (-0.35, -0.30, -0.15)
    w[g.L_WRIST], w[g.R_WRIST] = (0.30, 0.02, -0.05), (-0.45, -0.25, -0.40)
    for i, base in [(17, g.L_WRIST), (19, g.L_WRIST), (21, g.L_WRIST)]:
        w[i] = w[base] + (0.02, 0.06, -0.01)
    for i, base in [(18, g.R_WRIST), (20, g.R_WRIST), (22, g.R_WRIST)]:
        w[i] = w[base] + (-0.03, 0.02, -0.07)
    w[g.L_HIP], w[g.R_HIP] = (0.10, 0.0, 0.0), (-0.10, 0.0, 0.0)
    w[g.L_KNEE], w[g.R_KNEE] = (0.14, 0.42, -0.08), (-0.13, 0.43, -0.05)
    w[g.L_ANKLE], w[g.R_ANKLE] = (0.15, 0.84, 0.02), (-0.15, 0.85, 0.03)
    w[29], w[30] = w[g.L_ANKLE] + (0, 0.04, 0.05), w[g.R_ANKLE] + (0, 0.04, 0.05)
    w[31], w[32] = w[g.L_ANKLE] + (0, 0.05, -0.12), w[g.R_ANKLE] + (0, 0.05, -0.12)
    return w


def random_rotation():
    """A random 3x3 rotation: orthogonal (Q^T Q = I) with determinant +1."""
    q, r = np.linalg.qr(RNG.normal(size=(3, 3)))
    q = q @ np.diag(np.sign(np.diag(r)))
    if np.linalg.det(q) < 0:
        q[:, 0] *= -1
    return q


def angles_close(a, b, names=None, tol=1e-6):
    for n in names or g.ANGLE_NAMES:
        assert abs(a[n] - b[n]) < tol, (n, a[n], b[n])


GENERAL = [n for n in g.ANGLE_NAMES if n not in ('Hip-shoulder separation', 'Trunk tilt')]
# Separation and trunk tilt refer to a vertical axis, so they are only invariant
# under rotations about that axis; the other angles are invariant under all rotations.


# -------------------------------------------------------------- invariances
def test_rotation_matrix_is_orthogonal():
    q = random_rotation()
    assert np.allclose(q.T @ q, np.eye(3)) and np.isclose(np.linalg.det(q), 1)


def test_translation_scale_rotation_invariance():
    w = skeleton()
    base = g.joint_angles(w)
    for _ in range(20):
        q, s, t = random_rotation(), RNG.uniform(0.3, 3.0), RNG.normal(size=3)
        angles_close(base, g.joint_angles(s * w @ q.T + t), GENERAL)


def test_vertical_axis_rotation_keeps_every_angle():
    w = skeleton()
    th = RNG.uniform(0, 2 * np.pi)
    q = np.array([[np.cos(th), 0, np.sin(th)], [0, 1, 0], [-np.sin(th), 0, np.cos(th)]])
    angles_close(g.joint_angles(w), g.joint_angles(w @ q.T))


def test_reflection_preserves_angles_but_flips_chirality():
    """The EPQ bug: a mirror image has identical joint angles..."""
    w = skeleton()
    m = g.reflect_x(w)
    angles_close(g.joint_angles(w), g.joint_angles(m), GENERAL + ['Trunk tilt'])
    # ...but the signed separation and the triple product both change sign.
    assert abs(g.joint_angles(w)['Hip-shoulder separation']) > 5
    assert np.isclose(g.joint_angles(m)['Hip-shoulder separation'],
                      -g.joint_angles(w)['Hip-shoulder separation'])
    assert g.chirality(m) == -g.chirality(w) != 0


def test_any_improper_orthogonal_map_flips_chirality():
    w = skeleton()
    for _ in range(20):
        q = random_rotation() @ np.diag([1, 1, -1])     # determinant -1
        assert np.isclose(np.linalg.det(q), -1)
        assert g.chirality(w @ q.T) == -g.chirality(w)


def test_rotation_keeps_chirality():
    w = skeleton()
    for _ in range(20):
        assert g.chirality(w @ random_rotation().T) == g.chirality(w)


def test_label_swap_flips_chirality():
    """A left/right mix-up by the pose estimator looks exactly like a reflection."""
    w = skeleton()
    assert g.chirality(g.swap_labels(w)) == -g.chirality(w)


def test_mirror_skeleton_makes_a_valid_body():
    """Reflect + swap labels = a correctly labelled real body of the other
    handedness: chirality is unchanged and mirroring twice is the identity."""
    w = skeleton()
    m = g.mirror_skeleton(w)
    assert g.chirality(m) == g.chirality(w)
    assert np.allclose(g.mirror_skeleton(m), w)
    # The right-hander's hitting arm becomes the mirrored player's left arm...
    a, b = g.joint_angles(w, 'right'), g.joint_angles(m, 'left')
    angles_close(a, b, [n for n in g.ANGLE_NAMES if n != 'Hip-shoulder separation'])
    # ...and a left-hander turns the other way, so the signed separation flips.
    assert abs(a['Hip-shoulder separation']) > 5
    assert np.isclose(b['Hip-shoulder separation'], -a['Hip-shoulder separation'])


# ---------------------------------------------------------------- angle values
def test_straight_and_right_angles():
    assert np.isclose(g.angle([1, 0, 0], [0, 0, 0], [-1, 0, 0]), 180)
    assert np.isclose(g.angle([1, 0, 0], [0, 0, 0], [0, 1, 0]), 90)
    assert np.isnan(g.angle([0, 0, 0], [0, 0, 0], [1, 0, 0]))


def test_signed_horizontal_angle():
    assert np.isclose(abs(g.signed_horizontal_angle([1, 0, 0], [0, 0, 1])), 90)
    assert np.isclose(g.signed_horizontal_angle([1, 0, 0], [0, 0, 1]),
                      -g.signed_horizontal_angle([0, 0, 1], [1, 0, 0]))
    # vertical components are ignored
    assert np.isclose(g.signed_horizontal_angle([1, 5, 0], [1, -3, 0]), 0)


def test_low_visibility_angles_are_dropped():
    vis = np.ones(33)
    vis[g.R_WRIST] = 0.1
    a = g.masked_joint_angles(skeleton(), vis, 'right')
    assert np.isnan(a['Hitting elbow']) and np.isnan(a['Hitting wrist'])
    assert np.isfinite(a['Other elbow'])


# ------------------------------------------------------------- time series
def test_smoothing_reduces_noise():
    t = np.linspace(0, 2 * np.pi, 120)
    clean = np.sin(t)
    noisy = clean + RNG.normal(scale=0.1, size=t.size)
    assert np.mean((g.smooth(noisy, 9, 2) - clean) ** 2) < 0.5 * np.mean((noisy - clean) ** 2)


def test_savgol_preserves_quadratics():
    x = np.arange(30.0) ** 2
    assert np.allclose(g.smooth(x, 7, 2)[3:-3], x[3:-3])


def test_interpolation_fills_short_gaps_only():
    x = np.array([0, np.nan, 2, 3, np.nan, np.nan, np.nan, np.nan, 8])
    y = g.interpolate_nans(x, max_gap=2)
    assert y[1] == 1 and np.isnan(y[5])


def test_contact_and_hitting_arm_detection():
    fps, T = 30, 60
    seq = np.repeat(skeleton()[None], T, axis=0)
    swing = np.exp(-((np.arange(T) - 37) / 4.0) ** 2)      # fast at frame 37
    seq[:, g.L_WRIST, 0] += np.cumsum(swing) * 0.05
    assert g.detect_hitting_arm(seq, fps) == 'left'
    assert abs(g.detect_contact(seq, fps, 'left') - 37) <= 1


def test_single_frame_glitch_does_not_decide_hitting_arm():
    """A right-hander whose LEFT wrist jumps wildly for one frame (a tracking
    glitch) must still be detected as right-handed."""
    fps, T = 30, 60
    seq = np.repeat(skeleton()[None], T, axis=0)
    swing = np.exp(-((np.arange(T) - 30) / 4.0) ** 2)
    seq[:, g.R_WRIST, 0] += np.cumsum(swing) * 0.05        # genuine swing, several frames
    seq[45, g.L_WRIST] += (2.0, 0, 0)                       # one-frame glitch, much "faster"
    assert np.max(g.speed(seq[:, g.L_WRIST], fps)) > np.max(g.speed(seq[:, g.R_WRIST], fps))
    hand, ratio = g.detect_hitting_arm(seq, fps, return_ratio=True)
    assert hand == 'right' and ratio > 1.3
    assert abs(g.detect_contact(seq, fps, 'right') - 30) <= 1


def test_similar_wrist_speeds_give_low_confidence():
    fps, T = 30, 60
    seq = np.repeat(skeleton()[None], T, axis=0)
    swing = np.exp(-((np.arange(T) - 30) / 4.0) ** 2)
    seq[:, g.R_WRIST, 0] += np.cumsum(swing) * 0.05
    seq[:, g.L_WRIST, 0] += np.cumsum(swing) * 0.048
    assert g.detect_hitting_arm(seq, fps, return_ratio=True)[1] < 1.3


def _turning_body(T=40):
    """A body turning smoothly about the vertical axis, as in a real clip."""
    out = []
    for t in range(T):
        th = np.radians(2.0 * t)
        q = np.array([[np.cos(th), 0, np.sin(th)], [0, 1, 0], [-np.sin(th), 0, np.cos(th)]])
        out.append(skeleton() @ q.T)
    return np.stack(out)


def test_label_flips_within_a_video_are_corrected():
    """Frames where the model swapped left and right are found by movement continuity and fixed."""
    T = 40
    seq = _turning_body(T)
    vis = np.tile(np.linspace(0.5, 1, 33), (T, 1))
    original = seq.copy()
    for t in (5, 6, 20):
        seq[t] = g.swap_labels(seq[t])
        vis[t] = vis[t][g.LR_SWAP]
    fixed, fixed_vis, n = g.fix_label_flips(seq, vis)
    assert n == 3 and np.allclose(fixed, original)
    assert np.allclose(fixed_vis, np.tile(np.linspace(0.5, 1, 33), (T, 1)))


def _turn_head(world, degrees):
    w = world.copy()
    sh = (w[g.L_SHOULDER] + w[g.R_SHOULDER]) / 2
    a = np.radians(degrees)
    q = np.array([[np.cos(a), 0, np.sin(a)], [0, 1, 0], [-np.sin(a), 0, np.cos(a)]])
    w[g.NOSE] = sh + q @ (w[g.NOSE] - sh)
    return w


def test_head_turned_to_watch_contact_is_not_a_label_swap():
    """Regression test for the v3 contact bug: turning the head ~100 degrees to watch the
    ball flips the raw triple product, but must NOT be 'corrected' as a left/right swap,
    and must not move the contact frame."""
    T = 70
    seq = np.repeat(skeleton()[None], T, axis=0)
    seq[:, g.R_WRIST, 0] += 0.4 * np.tanh((np.arange(T) - 38) / 4.0)
    for t in range(30, 46):
        seq[t] = _turn_head(seq[t], 100)
    assert g.chirality(seq[38]) != g.chirality(seq[0])        # the raw sign does flip...
    assert g.confident_chirality(seq[38]) == 0                 # ...but is flagged as untrustworthy
    fixed, n = g.fix_label_flips(seq)
    assert n == 0 and np.allclose(fixed, seq)
    assert abs(g.detect_contact(fixed, 30) - 38) <= 1
    assert g.sequence_chirality(seq) == g.chirality(seq[0])


def _swing(T, t0, width, rise=0.0, fps=30):
    """A right-hander swinging the racket hand across the body around frame t0."""
    seq = np.repeat(skeleton()[None], T, axis=0)
    u = np.tanh((np.arange(T) - t0) / width)
    seq[:, g.R_WRIST, 0] += 0.4 * u
    seq[:, g.R_WRIST, 1] -= rise * 0.5 * (u + 1)        # y down: subtracting raises the hand
    return seq


def test_stroke_window_scales_with_slow_motion():
    """The same swing filmed 4x slower gets a window 4x as many frames long."""
    normal = _swing(200, 60, 3.0)
    slow = _swing(800, 240, 12.0)
    c1, c2 = g.detect_contact(normal, 30), g.detect_contact(slow, 30)
    lo1, hi1, _ = g.stroke_window(normal, 30, c1)
    lo2, hi2, _ = g.stroke_window(slow, 30, c2)
    assert abs((hi2 - lo2) / (hi1 - lo1) - 4) < 0.6
    assert lo1 < c1 < hi1 and lo2 < c2 < hi2


def test_serve_contact_is_taken_above_the_head():
    """A fast arm movement below the head (racket drop) must not be chosen as serve contact."""
    T = 80
    seq = np.repeat(skeleton()[None], T, axis=0)
    drop = np.exp(-((np.arange(T) - 20) / 3.0) ** 2)       # fast, low movement first
    seq[:, g.R_WRIST, 0] += np.cumsum(drop) * 0.25
    up = 0.5 * (np.tanh((np.arange(T) - 55) / 4.0) + 1)     # then the hand goes up above the head
    seq[:, g.R_WRIST, 1] -= up * 1.0
    assert g.detect_contact(seq, 30, 'right', 'speed') < 40
    c = g.detect_contact(seq, 30, 'right', 'serve')
    assert c > 45 and -seq[c, g.R_WRIST, 1] > -seq[c, g.NOSE, 1]


def test_swing_rise_sign_separates_topspin_from_slice():
    up, down = _swing(120, 60, 4.0, rise=+0.6), _swing(120, 60, 4.0, rise=-0.6)
    vals = []
    for seq in (up, down):
        c = g.detect_contact(seq, 30)
        lo, hi, start = g.stroke_window(seq, 30, c)
        vals.append(g.stroke_metrics(seq, None, 30, 'right', c, lo, hi, start)[g.M_RISE])
    assert vals[0] > 0.2 and vals[1] < -0.2


def test_sync_map_matches_contact_and_never_goes_back():
    a = _swing(150, 50, 3.0)
    b = _swing(260, 120, 6.0)                                # slower student, later in the clip
    ca, cb = g.detect_contact(a, 30), g.detect_contact(b, 30)
    pa_, pb_ = g.stroke_window(a, 30, ca), g.stroke_window(b, 30, cb)
    fa = a[pa_[0]:pa_[1], g.R_WRIST, :1]
    fb = b[pb_[0]:pb_[1], g.R_WRIST, :1]
    _, path = g.dtw(fa, fb, band=0.5)
    m = g.sync_map(len(a), len(b), path, pa_[0], pa_[1], pb_[0], pb_[1])
    assert len(m) == len(a) and np.all(np.diff(m) >= 0) and m.min() >= 0 and m.max() <= len(b) - 1
    assert abs(m[ca] - cb) <= 2


def test_dtw_recovers_a_time_warp():
    t = np.linspace(0, 1, 50)
    a = np.sin(2 * np.pi * t)[:, None]
    warped_t = t ** 1.6                                      # same motion, different timing
    b = np.sin(2 * np.pi * warped_t)[:, None]
    cost_warped, path = g.dtw(a, b, band=0.5)
    shifted = np.sin(2 * np.pi * t + 1.0)[:, None]
    cost_different, _ = g.dtw(a, shifted, band=0.5)
    assert path[0] == (0, 0) and path[-1] == (49, 49)
    assert cost_warped < cost_different
    assert all(i2 >= i1 and j2 >= j1 for (i1, j1), (i2, j2) in zip(path, path[1:]))


def test_dtw_of_identical_sequences_is_zero():
    a = RNG.normal(size=(25, 3))
    cost, path = g.dtw(a, a)
    assert cost == 0 and path == [(i, i) for i in range(25)]



def test_stroke_rules_fire_and_rank():
    import coaching
    import strokes
    pro = {g.M_KNEE: 120.0, g.M_RISE: 0.8, 'Hitting elbow': 150.0, g.M_TURN: 30.0}
    stu = {g.M_KNEE: 150.0, g.M_RISE: 0.2, 'Hitting elbow': 148.0, g.M_TURN: 29.0}
    v = coaching.evaluate('forehand', pro, stu)
    assert {c['measure'] for c in v['cues']} == {g.M_RISE, g.M_KNEE}   # elbow and turn are within threshold
    assert v['cues'][0]['priority'] >= v['cues'][1]['priority']
    assert any('Hitting elbow' in s for s in v['strengths'])
    for key in strokes.STROKES:                         # every rule names a real measure
        for measure, *_ in strokes.get(key)['rules']:
            assert measure in g.ANGLE_NAMES or measure in g.METRIC_UNITS, (key, measure)


if __name__ == '__main__':
    tests = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in tests:
        fn()
        print('PASS', fn.__name__)
    print(f'All {len(tests)} tests passed.')
