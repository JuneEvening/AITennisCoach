# AI Tennis Coach v3 - R Shiny entry point.
# Launch with shiny::runApp('.') from this folder, or runApp('<full path to this folder>').
library(shiny)
library(reticulate)

# Select Python BEFORE source_python() or any other Python call (set up by setup.R).
reticulate::use_virtualenv('aitenniscoach', required = TRUE)
options(shiny.maxRequestSize = 300 * 1024^2)

source_python('bin/pose_analysis.py')
source_python('bin/chatgpt_request.py')

# The pose model lives in models/ inside this app's folder (downloaded, not in the ZIP).
MODEL_FILE <- file.path(normalizePath('.'), 'models', 'pose_landmarker_heavy.task')
MODEL_URL <- paste0('https://storage.googleapis.com/mediapipe-models/pose_landmarker/',
                    'pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task')
if (file.exists(MODEL_FILE)) set_model_path(MODEL_FILE)

# FFmpeg makes videos playable in browsers. RStudio on a Mac often does not see the
# Homebrew PATH, so look in the usual install locations as well.
find_ffmpeg <- function() {
  hits <- c(unname(Sys.which('ffmpeg')), '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg')
  hits <- hits[nzchar(hits) & file.exists(hits)]
  if (length(hits)) hits[1] else ''
}
FFMPEG <- find_ffmpeg()

DEG <- '\u00b0'
STROKES <- c('Forehand' = 'forehand', 'Two-handed backhand' = 'backhand_2h',
             'One-handed backhand' = 'backhand_1h', 'Slice backhand' = 'slice',
             'Volley' = 'volley', 'Serve' = 'serve')
HANDS <- c('Detect automatically' = 'auto', 'Right-handed' = 'right', 'Left-handed' = 'left')
SLOWMO <- c('Normal speed' = 1, 'Slow motion x2' = 2, 'Slow motion x4' = 4, 'Slow motion x8' = 8)
LANGS <- c('English' = 'en', '中文 Chinese' = 'zh')
AGES <- c('Under 12' = 'u12', '12–15' = '12_15', '16–18' = '16_18', 'Adult (19–34)' = 'adult',
          '35 and over' = '35plus')
PHASES <- c('Contact' = 'contact', 'Preparation / backswing' = 'preparation', 'Follow-through' = 'follow_through')

# Report headings in the two advice languages.
TXT <- list(
  en = list(analysis = 'analysis', level = 'student level', goal = 'Goal', findings = 'Key findings (rule-based)',
            none = 'No difference was large enough to flag.', close = 'Already close to the professional:',
            advice = 'AI coaching advice', fitness = 'Injury prevention and fitness plan', followup = 'Follow-up question',
            contact = 'Contact', measures = 'Whole-stroke measures', angles = 'Joint angles at contact (degrees)',
            curves = 'Angles through the stroke', notes = 'Measurement notes', frames = 'Still-frame comparison',
            frame_angles = 'Joint angles in the selected frames (degrees)', phase = 'Phase shown',
            reliability = 'Reliability check', footer = 'Estimated from video with MediaPipe pose landmarks. General guidance only; not a medical assessment.'),
  zh = list(analysis = '分析报告', level = '学员水平', goal = '目标',
            findings = '主要发现（规则分析，英文）',
            none = '没有需要特别指出的差异。',
            close = '已接近职业球员的方面：',
            advice = 'AI 技术指导', fitness = '伤病预防与体能计划',
            followup = '追问', contact = '击球瞬间', measures = '整体动作指标',
            angles = '击球瞬间关节角度（度）',
            curves = '全动作关节角度变化', notes = '测量说明',
            frames = '静态帧对比', frame_angles = '所选帧的关节角度（度）',
            phase = '动作阶段', reliability = '可靠性检验',
            footer = '基于 MediaPipe 姿态估计的视频分析。仅供一般指导，不是医学诊断。'))

LEVELS <- c('Beginner' = 'beginner', 'Intermediate club player' = 'intermediate',
            'Advanced / county' = 'advanced', 'Competitive junior / tournament' = 'competitive')

# Browser-friendly copy of an upload: H.264 + AAC with the index at the start.
make_preview <- function(src, dst) {
  if (!nzchar(FFMPEG)) return(FALSE)
  run <- function(args) {
    out <- suppressWarnings(system2(FFMPEG, c('-hide_banner', '-loglevel', 'error', '-y', '-i', shQuote(src),
                                              args, shQuote(dst)), stdout = TRUE, stderr = TRUE))
    is.null(attr(out, 'status')) && file.exists(dst) && file.size(dst) > 0
  }
  run(c('-vf', shQuote('scale=trunc(iw/2)*2:trunc(ih/2)*2'), '-c:v', 'libx264', '-preset', 'veryfast',
        '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-movflags', '+faststart')) ||
    run(c('-c', 'copy', '-movflags', '+faststart'))
}

# ------------------------------------------------------------------ helpers
as_chr <- function(x) if (is.null(x)) character(0) else as.character(unlist(x))
as_num <- function(x) if (is.null(x)) numeric(0) else as.numeric(unlist(lapply(x, function(v) if (is.null(v)) NA else v)))
`%||%` <- function(a, b) if (is.null(a) || !length(a)) b else a

fmt_val <- function(x, unit) ifelse(is.na(x), 'n/a', ifelse(unit == 'degrees', sprintf('%.0f', x), sprintf('%.2f', x)))
fmt_diff <- function(x, unit) ifelse(is.na(x), 'n/a', ifelse(unit == 'degrees', sprintf('%+.0f', x), sprintf('%+.2f', x)))

metrics_df <- function(cmp) {
  t <- cmp$metrics_table
  u <- as_chr(t$Unit)
  data.frame(Measure = as_chr(t$Measure),
             Professional = fmt_val(as_num(t$Professional), u),
             Student = fmt_val(as_num(t$Student), u),
             `Student minus pro` = fmt_diff(as_num(t$Difference), u),
             Unit = u, `How to read it` = as_chr(cmp$metric_meaning),
             check.names = FALSE, stringsAsFactors = FALSE)
}
angles_df <- function(res) {
  t <- res$contact_table
  data.frame(Angle = as_chr(t$Angle),
             Professional = fmt_val(as_num(t$Professional), 'degrees'),
             Student = fmt_val(as_num(t$Student), 'degrees'),
             `Student minus pro` = fmt_diff(as_num(t$Difference), 'degrees'),
             check.names = FALSE, stringsAsFactors = FALSE)
}
curves_df <- function(cmp) {
  out <- data.frame(time_s_from_pro_contact = round(as.numeric(cmp$time), 3))
  for (j in as_chr(cmp$compared)) {
    out[[paste0(j, ' (professional)')]] <- round(as.numeric(cmp$pro_series[[j]]), 2)
    out[[paste0(j, ' (student, time-aligned)')]] <- round(as.numeric(cmp$student_series[[j]]), 2)
  }
  out
}

draw_angle_plot <- function(cmp, joint, main = joint) {
  t <- as.numeric(cmp$time)
  p <- as.numeric(cmp$pro_series[[joint]])
  s <- as.numeric(cmp$student_series[[joint]])
  yl <- range(c(p, s), na.rm = TRUE)
  if (!all(is.finite(yl))) yl <- c(0, 180)
  plot(t, p, type = 'l', lwd = 2, col = '#1f77b4', ylim = yl,
       xlab = "Time from the professional's contact (s)", ylab = paste0('Angle (', DEG, ')'), main = main)
  lines(t, s, lwd = 2, col = '#d62728', lty = 2)
  abline(v = 0, col = 'grey50', lty = 3)
  legend('topleft', c('Professional', 'Student (time-aligned)'), col = c('#1f77b4', '#d62728'),
         lty = c(1, 2), lwd = 2, bty = 'n', cex = 0.85)
}

html_table <- function(df) {
  esc <- htmltools::htmlEscape
  head <- paste0('<tr>', paste0('<th>', esc(names(df)), '</th>', collapse = ''), '</tr>')
  rows <- apply(df, 1, function(r) paste0('<tr>', paste0('<td>', esc(r), '</td>', collapse = ''), '</tr>'))
  paste0('<table>', head, paste(rows, collapse = ''), '</table>')
}
img64 <- function(path, type = 'image/jpeg', width = '48%') {
  if (is.null(path) || !length(path) || !file.exists(path)) return('')
  raw <- readBin(path, 'raw', file.info(path)$size)
  sprintf('<img src="data:%s;base64,%s" style="width:%s;margin:4px">', type, jsonlite::base64_enc(raw), width)
}
md_html <- function(x) if (is.null(x) || !nzchar(x)) '' else commonmark::markdown_html(x)

# Video player with its own frame slider, step buttons and a jump-to-contact button.
player_ui <- function(id, title, src, fps = 30, frames = NA, contact = NA, note = NULL) {
  attrs <- list(id = paste0('vid_', id), src = src, preload = 'auto', playsinline = NA, muted = NA,
                `data-fps` = fps)
  if (!is.na(frames)) attrs$`data-frames` <- frames
  if (!is.na(contact)) attrs$`data-contact` <- contact
  maxf <- if (is.na(frames)) 100 else max(frames - 1, 1)
  btn <- function(label, js, title) tags$button(type = 'button', class = 'btn btn-default btn-sm', title = title,
                                                onclick = js, label)
  div(class = 'vcol',
      h4(title),
      div(class = 'vbox', do.call(tags$video, attrs)),
      div(class = 'vctrl',
          btn('\u25B6\u2009/\u2009\u23F8', sprintf("tc.play('%s')", id), 'Play / pause'),
          btn('\u2212 1', sprintf("tc.step('%s',-1)", id), 'Back one frame'),
          tags$input(type = 'range', class = 'scrub', id = paste0('rng_', id), min = 0, max = maxf,
                     value = 0, step = 1),
          btn('+ 1', sprintf("tc.step('%s',1)", id), 'Forward one frame'),
          if (!is.na(contact)) btn('Contact', sprintf("tc.contact('%s')", id), 'Jump to contact')),
      div(class = 'flabel', id = paste0('lab_', id), 'frame 0'),
      if (!is.null(note)) p(class = 'note', note))
}

PLAYER_JS <- r"--(
window.tc = {
  vid: function(id) { return document.getElementById('vid_' + id); },
  fps: function(v) { return parseFloat(v.dataset.fps) || 30; },
  seekFrame: function(id, f) {
    var v = this.vid(id); if (!v) return;
    v.pause(); f = Math.max(0, f);
    if (v.dataset.frames) f = Math.min(f, parseInt(v.dataset.frames) - 1);
    v.currentTime = (f + 0.5) / this.fps(v);
  },
  frameOf: function(v) { return Math.floor(v.currentTime * this.fps(v) + 1e-6); },
  step: function(id, d) { var v = this.vid(id); if (v) this.seekFrame(id, this.frameOf(v) + d); },
  play: function(id) { var v = this.vid(id); if (!v) return; if (v.paused) v.play(); else v.pause(); },
  contact: function(id) { var v = this.vid(id); if (v && v.dataset.contact !== undefined) this.seekFrame(id, parseInt(v.dataset.contact)); },
  sync: function(i) {
    var s = document.getElementById('tc_sync'); if (!s) return;
    var map = JSON.parse(s.dataset.map); i = Math.max(0, Math.min(parseInt(i), map.length - 1));
    s.value = i; this.seekFrame('pro', i); this.seekFrame('stu', map[i]);
    var l = document.getElementById('tc_sync_lab');
    if (l) l.textContent = 'professional frame ' + i + '  \u2194  student frame ' + map[i] +
      (i == parseInt(s.dataset.contact) ? '   (contact)' : '');
  },
  syncStep: function(d) { var s = document.getElementById('tc_sync'); if (s) this.sync(parseInt(s.value) + d); },
  syncContact: function() { var s = document.getElementById('tc_sync'); if (s) this.sync(parseInt(s.dataset.contact)); }
};
function tcUpdate(e) {
  var v = e.target; if (!v || !v.id || v.id.indexOf('vid_') !== 0) return;
  var id = v.id.slice(4), f = tc.frameOf(v);
  var r = document.getElementById('rng_' + id); if (r && document.activeElement !== r) r.value = f;
  var l = document.getElementById('lab_' + id);
  if (l) l.textContent = 'frame ' + f + '  \u00b7  ' + v.currentTime.toFixed(2) + ' s' +
    (v.dataset.contact !== undefined && f == parseInt(v.dataset.contact) ? '  \u00b7  contact' : '');
}
document.addEventListener('timeupdate', tcUpdate, true);
document.addEventListener('seeked', tcUpdate, true);
document.addEventListener('loadedmetadata', function(e) {
  var v = e.target; if (!v || !v.id || v.id.indexOf('vid_') !== 0) return;
  var r = document.getElementById('rng_' + v.id.slice(4));
  if (r && !v.dataset.frames) r.max = Math.max(1, Math.floor(v.duration * tc.fps(v)) - 1);
}, true);
document.addEventListener('input', function(e) {
  var t = e.target;
  if (t.classList && t.classList.contains('scrub')) tc.seekFrame(t.id.replace('rng_', ''), parseInt(t.value));
  if (t.id === 'tc_sync') tc.sync(t.value);
});
)--"

# ----------------------------------------------------------------------- UI
ui <- fluidPage(
  tags$head(
    tags$style(HTML('
      .vbox { width:100%; aspect-ratio:1/1; background:#111; border-radius:6px; overflow:hidden; }
      .vbox video { width:100%; height:100%; object-fit:contain; display:block; }
      .vctrl { display:flex; align-items:center; gap:6px; margin-top:6px; }
      .vctrl input[type=range] { flex:1; min-width:60px; }
      .flabel { font-size:85%; color:#555; margin-top:2px; font-variant-numeric:tabular-nums; }
      .syncbar { background:#f4f7fb; border:1px solid #dbe4ef; border-radius:6px; padding:10px 14px; margin:14px 0; }
      .syncbar input[type=range] { width:100%; }
      .wide .vbox { aspect-ratio:2/1; }
      .note { color:#666; font-size:90%; }
      .pose-image { width:100%; aspect-ratio:1/1; border:1px solid #ddd; background:#f5f5f5; }
      .pose-image img { width:100% !important; height:100% !important; object-fit:contain; }
      .advice h2 { font-size:1.25em; margin-top:1.1em; }
      .strength { color:#2e7d32; }
    ')),
    tags$script(HTML(PLAYER_JS))
  ),
  titlePanel('\U0001F3BE AI Tennis Coach v3'),
  sidebarLayout(
    sidebarPanel(width = 3,
      selectInput('stroke', 'Stroke', STROKES),
      h4('Professional'),
      fileInput('pro_video', NULL, accept = c('.mp4', '.mov'), buttonLabel = 'Upload video'),
      fluidRow(column(6, selectInput('pro_hand', 'Hand', HANDS, 'right')),
               column(6, selectInput('pro_slow', 'Speed', SLOWMO))),
      h4('Student'),
      fileInput('student_video', NULL, accept = c('.mp4', '.mov'), buttonLabel = 'Upload video'),
      fluidRow(column(6, selectInput('student_hand', 'Hand', HANDS, 'right')),
               column(6, selectInput('student_slow', 'Speed', SLOWMO))),
      sliderInput('target_fps', 'Analysis frame rate (fps)', min = 10, max = 60, value = 30, step = 5),
      actionButton('analyse', 'Analyse and compare', class = 'btn-primary btn-block'),
      hr(),
      h4('AI Tennis Coach'),
      radioButtons('lang', 'Advice language', LANGS, 'en', inline = TRUE),
      fluidRow(column(6, selectInput('level', 'Level', LEVELS, 'intermediate')),
               column(6, selectInput('age', 'Age group', AGES, '12_15'))),
      textAreaInput('goals', 'Goal or concern (optional)', rows = 2,
                    placeholder = 'e.g. my forehand lands short; my shoulder gets tired'),
      actionButton('advice', 'Technique advice', class = 'btn-success btn-block'),
      actionButton('fitness', 'Injury prevention & fitness plan', class = 'btn-info btn-block'),
      textAreaInput('question', 'Ask the coach a follow-up question', rows = 2),
      actionButton('ask', 'Ask'),
      textInput('ai_model', 'AI model', Sys.getenv('OPENAI_MODEL', 'gpt-4o-mini')),
      hr(),
      h4('Downloads'),
      downloadButton('dl_report', 'Report (HTML / PDF)', class = 'btn-block'),
      downloadButton('dl_csv', 'Data (CSV)', class = 'btn-block'),
      downloadButton('dl_bundle', 'Everything incl. videos (ZIP)', class = 'btn-block'),
      p(class = 'note', 'To get a PDF, open the HTML report and use Print \u2192 Save as PDF.'),
      hr(),
      h4('Still frames'),
      numericInput('frame_fps', 'Frames per second to extract', value = 5, min = 1, max = 30),
      actionButton('extract', 'Extract and annotate frames'),
      uiOutput('pro_selector'), uiOutput('student_selector'),
      actionButton('compare_frames', 'Compare selected frames'),
      actionButton('reliability', 'Reliability check')
    ),
    mainPanel(width = 9,
      uiOutput('model_banner'),
      tabsetPanel(id = 'tabs',
        tabPanel('Motion',
          fluidRow(column(6, uiOutput('pro_player')), column(6, uiOutput('stu_player'))),
          uiOutput('sync_ui'),
          uiOutput('sbs_ui'),
          h4('Summary'), verbatimTextOutput('motion_summary'),
          h4('Whole-stroke measures'),
          p(class = 'note', 'Lengths are in trunk lengths (shoulders to hips), so players of different sizes compare fairly.'),
          tableOutput('metrics_table'),
          h4(paste0('Joint angles at contact (', DEG, ')')),
          p(class = 'note', 'Elbow, knee, wrist: 180 = straight. Shoulder: angle between upper arm and side of trunk.'),
          tableOutput('contact_table'),
          fluidRow(column(6, selectInput('plot_joint', 'Angle through the stroke', character(0)))),
          plotOutput('angle_plot', height = '340px')
        ),
        tabPanel('Coaching',
          h4('What the measurements show'), uiOutput('cues_ui'),
          h4('AI technique advice'), uiOutput('advice_ui'),
          h4('Injury prevention and fitness plan'), uiOutput('fitness_ui'),
          h4('Follow-up answer'), uiOutput('answer_ui')
        ),
        tabPanel('Still frames',
          fluidRow(column(6, h4('Professional'), div(class = 'pose-image', imageOutput('pro_image', height = 'auto'))),
                   column(6, h4('Student'), div(class = 'pose-image', imageOutput('student_image', height = 'auto')))),
          fluidRow(column(4, selectInput('frame_phase', 'Phase these frames show', PHASES)),
                   column(8, br(),
                          actionButton('frame_advice', 'AI technique advice on these frames', class = 'btn-success'),
                          actionButton('frame_fitness', 'Injury prevention & fitness', class = 'btn-info'),
                          downloadButton('dl_frame_report', 'Still-frame report'))),
          p(class = 'note', 'Choose the frames in the sidebar, set the phase, then click "Compare selected frames".'),
          tableOutput('frame_table'), verbatimTextOutput('frame_notes'),
          uiOutput('frame_cues_ui'),
          h4('AI technique advice (still frames)'), uiOutput('frame_advice_ui'),
          h4('Injury prevention and fitness (still frames)'), uiOutput('frame_fitness_ui')
        ),
        tabPanel('Reliability',
          p('The selected student frame is re-detected under small random crops. The standard deviation (SD)',
            'estimates measurement error: differences smaller than about twice the SD may be noise.'),
          tableOutput('rel_table')
        ),
        tabPanel('About',
          p('Strokes supported: forehand, one- and two-handed backhand, slice backhand, volley and serve.'),
          p('Joint angles come from normalised dot products of 3D world landmarks, so they ignore position, size',
            'and camera rotation. Reflections preserve them too, so handedness is checked with the sign of a',
            'triple product, left-handers are mirrored, and left/right label swaps are corrected frame by frame.'),
          p('Contact is estimated from peak racket-hand speed (above the head for serves). The stroke window is',
            'sized from the swing itself, so slow-motion clips work. The two strokes are aligned with dynamic time',
            'warping, which also drives the linked slider and the side-by-side video.'),
          p('Estimates from video; not an injury assessment.')
        )
      )
    )
  )
)

# ------------------------------------------------------------------- server
server <- function(input, output, session) {
  token <- gsub('[^A-Za-z0-9]', '', session$token)
  workdir <- file.path(tempdir(), paste0('tennis_', token))
  dir.create(workdir, recursive = TRUE, showWarnings = FALSE)
  res_prefix <- paste0('media_', token)
  addResourcePath(res_prefix, workdir)
  session$onSessionEnded(function() {
    unlink(workdir, recursive = TRUE)
    try(removeResourcePath(res_prefix), silent = TRUE)
  })
  path <- function(...) file.path(workdir, ...)
  url <- function(file, stamp) {
    rel <- if (startsWith(file, workdir)) substring(file, nchar(workdir) + 2) else basename(file)
    paste0(res_prefix, '/', rel, '?v=', stamp)
  }
  pro_upload <- path('pro_upload.mp4');   stu_upload <- path('student_upload.mp4')
  pro_preview <- path('pro_preview.mp4'); stu_preview <- path('student_preview.mp4')

  state <- reactiveValues(pro_video = NULL, student_video = NULL, motion = NULL, sbs = NULL,
                          pro_frames = NULL, student_frames = NULL, frame_result = NULL,
                          reliability = NULL, advice = NULL, fitness = NULL, answer = NULL,
                          frame_advice = NULL, frame_fitness = NULL,
                          active = 'none', stamp = 0, upload_stamp = 0)
  notify_error <- function(e) showNotification(conditionMessage(e), type = 'error', duration = NULL)
  hand_for <- function(choice, analysed) {
    if (!identical(choice, 'auto')) return(choice)
    if (!is.null(analysed)) return(as.character(analysed$hitting_arm))
    'auto'
  }

  # ------------------------------------------------------------ pose model
  model_found <- reactiveVal(nzchar(find_model()))
  output$model_banner <- renderUI({
    if (model_found()) return(NULL)
    div(style = 'background:#fdecea;border:1px solid #f5c2c0;padding:12px;margin:10px 0;border-radius:6px',
        strong('The pose model is not installed yet.'),
        p('The app needs pose_landmarker_heavy.task in:', code(dirname(MODEL_FILE))),
        actionButton('download_model', 'Download pose model (about 30 MB)', class = 'btn-danger'))
  })
  observeEvent(input$download_model, {
    withProgress(message = 'Downloading the pose model', value = 0.3, {
      tryCatch({
        dir.create(dirname(MODEL_FILE), recursive = TRUE, showWarnings = FALSE)
        options(timeout = max(900, getOption('timeout')))
        download.file(MODEL_URL, MODEL_FILE, mode = 'wb', quiet = TRUE)
        if (!file.exists(MODEL_FILE) || file.size(MODEL_FILE) < 1e6) stop('The downloaded file is too small.')
        set_model_path(MODEL_FILE)
        model_found(nzchar(find_model()))
        showNotification('Pose model installed.', type = 'message')
      }, error = function(e) {
        if (file.exists(MODEL_FILE) && file.size(MODEL_FILE) < 1e6) unlink(MODEL_FILE)
        showNotification(paste('Download failed:', conditionMessage(e), '- save the file manually into',
                               dirname(MODEL_FILE)), type = 'error', duration = NULL)
      })
    })
  })
  need_model <- function() {
    if (model_found()) return(TRUE)
    showNotification('Install the pose model first (red box at the top).', type = 'error')
    FALSE
  }

  # --------------------------------------------------------------- uploads
  reset <- function() {
    state$pro_video <- NULL; state$student_video <- NULL; state$motion <- NULL; state$sbs <- NULL
    state$pro_frames <- NULL; state$student_frames <- NULL; state$frame_result <- NULL
    state$reliability <- NULL; state$advice <- NULL; state$fitness <- NULL; state$answer <- NULL
    state$frame_advice <- NULL; state$frame_fitness <- NULL; state$active <- 'none'
  }
  take_upload <- function(info, upload, preview) {
    file.copy(info$datapath, upload, overwrite = TRUE)
    unlink(preview)
    if (nzchar(FFMPEG)) withProgress(message = 'Preparing video preview', value = 0.5, {
      if (!make_preview(upload, preview))
        showNotification('Could not convert this video for the browser; showing the original.', type = 'warning')
    })
    reset(); state$upload_stamp <- as.numeric(Sys.time())
  }
  observeEvent(input$pro_video, take_upload(input$pro_video, pro_upload, pro_preview))
  observeEvent(input$student_video, take_upload(input$student_video, stu_upload, stu_preview))
  observeEvent(input$stroke, { state$motion <- NULL; state$sbs <- NULL; state$advice <- NULL
                               state$pro_video <- NULL; state$student_video <- NULL }, ignoreInit = TRUE)

  # ------------------------------------------------------- motion analysis
  observeEvent(input$analyse, {
    req(input$pro_video, input$student_video)
    if (!need_model()) return()
    withProgress(message = 'Analysing strokes', value = 0, {
      tryCatch({
        incProgress(0.05, detail = 'professional video')
        pv <- analyse_video(pro_upload, path('motion'), 'pro', input$pro_hand, as.integer(input$target_fps),
                            450L, FFMPEG, 7L, input$stroke, as.numeric(input$pro_slow))
        incProgress(0.4, detail = 'student video')
        sv <- analyse_video(stu_upload, path('motion'), 'student', input$student_hand,
                            as.integer(input$target_fps), 450L, FFMPEG, 7L, input$stroke,
                            as.numeric(input$student_slow))
        incProgress(0.3, detail = 'aligning the strokes')
        cmp <- compare_videos(pv$npz, sv$npz, input$stroke)
        state$pro_video <- pv; state$student_video <- sv; state$motion <- cmp
        state$sbs <- NULL; state$advice <- NULL; state$fitness <- NULL; state$answer <- NULL
        if (isTRUE(cmp$match)) {
          incProgress(0.15, detail = 'side-by-side video')
          state$sbs <- tryCatch(make_side_by_side(pv$annotated_video, sv$annotated_video, cmp$sync_map,
                                                  path('motion', 'side_by_side.mp4'), FFMPEG),
                                error = function(e) NULL)
          joints <- as_chr(cmp$compared)
          updateSelectInput(session, 'plot_joint', choices = joints,
                            selected = if ('Hitting elbow' %in% joints) 'Hitting elbow' else joints[1])
        } else showNotification(cmp$message, type = 'warning')
        state$stamp <- as.numeric(Sys.time()); state$active <- 'motion'
        updateTabsetPanel(session, 'tabs', selected = 'Motion')
      }, error = notify_error)
    })
  })

  player_for <- function(who) {
    v <- if (who == 'pro') state$pro_video else state$student_video
    upload <- if (who == 'pro') pro_upload else stu_upload
    preview <- if (who == 'pro') pro_preview else stu_preview
    info <- if (who == 'pro') input$pro_video else input$student_video
    title <- if (who == 'pro') 'Professional' else 'Student'
    id <- if (who == 'pro') 'pro' else 'stu'
    if (!is.null(v)) {
      player_ui(id, title, url(v$annotated_video, state$stamp), v$fps, as.integer(v$n_frames),
                as.integer(v$contact_frame), 'Hitting arm in green; green bar = analysed stroke window.')
    } else if (!is.null(info) && file.exists(upload)) {
      src <- if (file.exists(preview)) preview else upload
      player_ui(id, title, url(src, state$upload_stamp), 30, NA, NA,
                if (nzchar(FFMPEG)) 'Uploaded video. Analyse to add the skeleton and contact.'
                else 'FFmpeg not found: install it (brew install ffmpeg) if the video does not play.')
    } else {
      div(class = 'vcol', h4(title), div(class = 'vbox'), p(class = 'note', 'Upload a video.'))
    }
  }
  output$pro_player <- renderUI(player_for('pro'))
  output$stu_player <- renderUI(player_for('stu'))

  output$sync_ui <- renderUI({
    cmp <- state$motion
    req(isTRUE(cmp$match))
    m <- as.integer(unlist(cmp$sync_map)); pc <- as.integer(cmp$pro_contact)
    div(class = 'syncbar',
        strong('Compare matching moments'),
        span(class = 'note', ' \u2013 moves both videos together; the student is re-timed by dynamic time warping.'),
        tags$input(type = 'range', id = 'tc_sync', min = 0, max = length(m) - 1, value = pc, step = 1,
                   `data-map` = as.character(jsonlite::toJSON(m)), `data-contact` = pc),
        div(class = 'vctrl',
            tags$button(type = 'button', class = 'btn btn-default btn-sm', onclick = 'tc.syncStep(-1)', '\u2212 1'),
            tags$button(type = 'button', class = 'btn btn-primary btn-sm', onclick = 'tc.syncContact()', 'Both at contact'),
            tags$button(type = 'button', class = 'btn btn-default btn-sm', onclick = 'tc.syncStep(1)', '+ 1'),
            span(class = 'flabel', id = 'tc_sync_lab', 'Drag the slider')))
  })

  output$sbs_ui <- renderUI({
    req(state$sbs, state$pro_video)
    pv <- state$pro_video
    div(class = 'wide',
        player_ui('sbs', 'Side by side, synchronised', url(state$sbs, state$stamp), pv$fps,
                  as.integer(pv$n_frames), as.integer(pv$contact_frame),
                  'The student is re-timed so matching moments play together. Included in the ZIP download.'))
  })

  all_warnings <- reactive(unique(c(as_chr(state$pro_video$warnings), as_chr(state$student_video$warnings),
                                    as_chr(state$motion$warnings))))

  output$motion_summary <- renderText({
    req(state$motion)
    pv <- state$pro_video; sv <- state$student_video; cmp <- state$motion
    line <- function(lbl, v) sprintf('%s %s-handed (%s), contact at frame %d (%.2f s into clip), forward swing %.2f s real time, pose found in %.0f%% of frames',
                                     lbl, v$hitting_arm, v$hand_source, as.integer(v$contact_frame), v$contact_time,
                                     v$forward_swing_s, 100 * v$detected_fraction)
    out <- c(paste('Stroke:', cmp$stroke_label %||% names(STROKES)[STROKES == input$stroke]),
             line('Professional:', pv), line('Student:     ', sv))
    if (isTRUE(cmp$match)) out <- c(out, sprintf('Timing-adjusted difference (average DTW distance): %.2f', cmp$dtw_cost))
    else out <- c(out, cmp$message)
    w <- all_warnings()
    if (length(w)) out <- c(out, '', 'Notes:', paste('-', w))
    paste(out, collapse = '\n')
  })
  output$metrics_table <- renderTable({ req(isTRUE(state$motion$match)); metrics_df(state$motion) }, align = 'lrrrll')
  output$contact_table <- renderTable({ req(isTRUE(state$motion$match)); angles_df(state$motion) }, align = 'lrrr')
  output$angle_plot <- renderPlot({
    cmp <- state$motion
    req(isTRUE(cmp$match), input$plot_joint, input$plot_joint %in% as_chr(cmp$compared))
    draw_angle_plot(cmp, input$plot_joint)
  })

  # -------------------------------------------------------------- coaching
  active_result <- reactive({
    if (identical(state$active, 'motion')) state$motion
    else if (identical(state$active, 'frame')) state$frame_result
    else NULL
  })
  findings_ui <- function(res, phase = 'contact') {
    if (is.null(res) || !isTRUE(res$match)) return(NULL)
    if (!identical(phase, 'contact'))
      return(p(class = 'note', 'Rule-based findings apply to contact frames only; the AI coach interprets other phases.'))
    cues <- as_chr(res$cues); good <- as_chr(res$strengths)
    tagList(h4('What the measurements show'),
      if (length(cues)) tags$ol(lapply(cues, tags$li)) else p('No difference was large enough to flag.'),
      if (length(good)) tagList(p(strong('Already close to the professional:')),
                                tags$ul(class = 'strength', lapply(good, tags$li))))
  }
  output$frame_cues_ui <- renderUI(findings_ui(state$frame_result, state$frame_result$phase %||% 'contact'))
  output$cues_ui <- renderUI({
    res <- if (isTRUE(state$motion$match)) state$motion else state$frame_result
    if (is.null(res) || !isTRUE(res$match)) return(p(class = 'note', 'Run an analysis first.'))
    cues <- as_chr(res$cues); good <- as_chr(res$strengths)
    tagList(
      if (length(cues)) tagList(p(strong('Biggest differences first:')), tags$ol(lapply(cues, tags$li)))
      else p('No difference was large enough to flag for this stroke.'),
      if (length(good)) tagList(p(strong('Already close to the professional:')),
                                tags$ul(class = 'strength', lapply(good, tags$li))))
  })
  # The sidebar buttons work on the motion analysis if there is one, otherwise on the still frames.
  sidebar_target <- function() {
    if (isTRUE(state$motion$match)) 'motion' else if (isTRUE(state$frame_result$match)) 'frame' else 'none'
  }
  ask_ai <- function(res, kind = c('advice', 'fitness'), extra = NULL) {
    kind <- match.arg(kind)
    if (is.null(res) || !isTRUE(res$match)) return('Run an analysis first.')
    prompt <- if (kind == 'advice') advice_prompt(res$summary_json, input$level, input$goals, input$lang)
              else fitness_prompt(res$summary_json, input$level, input$age, input$goals, input$lang)
    if (!is.null(extra)) prompt <- paste0(prompt, '\n\nThe player now asks: ', extra,
                                          '\nAnswer this question specifically, using the measurements.')
    tryCatch(chatgptquery(prompt, if (kind == 'fitness') 2200L else 1500L, input$ai_model),
             error = function(e) paste('AI request failed:', conditionMessage(e)))
  }
  msg <- function(en, zh) if (identical(input$lang, 'zh')) zh else en
  observeEvent(input$advice, {
    tgt <- sidebar_target()
    withProgress(message = msg('The AI coach is analysing', 'AI \u6559\u7ec3\u6b63\u5728\u5206\u6790'), value = 0.5, {
      if (tgt == 'frame') state$frame_advice <- ask_ai(state$frame_result, 'advice')
      else state$advice <- ask_ai(state$motion, 'advice')
    })
    updateTabsetPanel(session, 'tabs', selected = if (tgt == 'frame') 'Still frames' else 'Coaching')
  })
  observeEvent(input$fitness, {
    tgt <- sidebar_target()
    withProgress(message = msg('Building the injury-prevention and fitness plan', '\u6b63\u5728\u5236\u5b9a\u4f24\u75c5\u9884\u9632\u4e0e\u4f53\u80fd\u8ba1\u5212'), value = 0.5, {
      if (tgt == 'frame') state$frame_fitness <- ask_ai(state$frame_result, 'fitness')
      else state$fitness <- ask_ai(state$motion, 'fitness')
    })
    updateTabsetPanel(session, 'tabs', selected = if (tgt == 'frame') 'Still frames' else 'Coaching')
  })
  observeEvent(input$frame_advice, {
    withProgress(message = msg('The AI coach is analysing the frames', 'AI \u6559\u7ec3\u6b63\u5728\u5206\u6790\u9759\u6001\u5e27'), value = 0.5,
                 state$frame_advice <- ask_ai(state$frame_result, 'advice'))
  })
  observeEvent(input$frame_fitness, {
    withProgress(message = msg('Building the plan', '\u6b63\u5728\u5236\u5b9a\u8ba1\u5212'), value = 0.5,
                 state$frame_fitness <- ask_ai(state$frame_result, 'fitness'))
  })
  observeEvent(input$ask, {
    req(nzchar(trimws(input$question)))
    res <- if (sidebar_target() == 'frame') state$frame_result else state$motion
    withProgress(message = msg('The AI coach is answering', 'AI \u6559\u7ec3\u6b63\u5728\u56de\u7b54'), value = 0.5,
                 state$answer <- ask_ai(res, 'advice', input$question))
    updateTabsetPanel(session, 'tabs', selected = 'Coaching')
  })
  ai_box <- function(x, hint) if (is.null(x)) p(class = 'note', hint) else div(class = 'advice', HTML(md_html(x)))
  output$advice_ui <- renderUI(ai_box(state$advice, 'Click "Technique advice" (needs OPENAI_API_KEY).'))
  output$fitness_ui <- renderUI(ai_box(state$fitness, 'Click "Injury prevention & fitness plan".'))
  output$frame_advice_ui <- renderUI(ai_box(state$frame_advice, 'Compare two frames, then click "AI technique advice on these frames".'))
  output$frame_fitness_ui <- renderUI(ai_box(state$frame_fitness, 'Optional: click "Injury prevention & fitness".'))
  output$answer_ui <- renderUI({ req(state$answer); div(class = 'advice', HTML(md_html(state$answer))) })

  # ---------------------------------------------------------- still frames
  observeEvent(input$extract, {
    req(input$pro_video, input$student_video)
    if (!need_model()) return()
    withProgress(message = 'Extracting and annotating frames', value = 0, {
      tryCatch({
        fps <- max(1, as.numeric(input$frame_fps))
        state$pro_frames <- as_chr(extract_frames(pro_upload, path('pro_frames'), fps))
        state$student_frames <- as_chr(extract_frames(stu_upload, path('student_frames'), fps))
        incProgress(0.3, detail = 'detecting poses')
        annotate_all_frames(path('pro_frames'), path('pro_frames_pose'), hand_for(input$pro_hand, state$pro_video))
        incProgress(0.3)
        annotate_all_frames(path('student_frames'), path('student_frames_pose'),
                            hand_for(input$student_hand, state$student_video))
        state$frame_result <- NULL
        updateTabsetPanel(session, 'tabs', selected = 'Still frames')
      }, error = notify_error)
    })
  })
  output$pro_selector <- renderUI({ req(state$pro_frames)
    selectInput('pro_choice', 'Professional frame', choices = state$pro_frames) })
  output$student_selector <- renderUI({ req(state$student_frames)
    selectInput('student_choice', 'Student frame', choices = state$student_frames) })
  frame_image <- function(choice, annotated_dir, original_dir) {
    req(choice)
    f <- path(annotated_dir, choice); if (!file.exists(f)) f <- path(original_dir, choice)
    req(file.exists(f))
    list(src = normalizePath(f), contentType = 'image/jpeg', width = '100%')
  }
  output$pro_image <- renderImage(frame_image(input$pro_choice, 'pro_frames_pose', 'pro_frames'), deleteFile = FALSE)
  output$student_image <- renderImage(frame_image(input$student_choice, 'student_frames_pose', 'student_frames'), deleteFile = FALSE)
  observeEvent(input$compare_frames, {
    req(input$pro_choice, input$student_choice)
    tryCatch({
      res <- compare_frames(path('pro_frames', input$pro_choice), path('student_frames', input$student_choice),
                            hand_for(input$pro_hand, state$pro_video), hand_for(input$student_hand, state$student_video),
                            path('comparison'), input$stroke, input$frame_phase)
      state$frame_result <- res; state$active <- 'frame'
      state$frame_advice <- NULL; state$frame_fitness <- NULL
      if (!isTRUE(res$match)) showNotification(res$message, type = 'warning')
    }, error = notify_error)
  })
  output$frame_table <- renderTable({ req(isTRUE(state$frame_result$match)); angles_df(state$frame_result) }, align = 'lrrr')
  output$frame_notes <- renderText({
    res <- state$frame_result; req(res)
    w <- as_chr(res$warnings)
    paste(c(res$message, 'Single frames may not show the same moment; motion analysis is more reliable.',
            if (length(w)) c('', 'Notes:', paste('-', w))), collapse = '\n')
  })

  # ----------------------------------------------------------- reliability
  observeEvent(input$reliability, {
    req(input$student_choice)
    withProgress(message = 'Re-detecting the frame under small crops', value = 0.3, {
      tryCatch({
        state$reliability <- reliability_check(path('student_frames', input$student_choice),
                                               hand_for(input$student_hand, state$student_video), 10L)
        updateTabsetPanel(session, 'tabs', selected = 'Reliability')
      }, error = notify_error)
    })
  })
  rel_df <- reactive({
    r <- state$reliability; req(r)
    tab <- r$table; m <- as_num(tab$Mean); s <- as_num(tab$SD)
    data.frame(Angle = as_chr(tab$Angle), Mean = ifelse(is.finite(m), sprintf('%.1f', m), 'n/a'),
               SD = ifelse(is.finite(s), sprintf('%.1f', s), 'n/a'),
               `Detected in` = sprintf('%d of %d', as.integer(unlist(tab$Detected)), as.integer(r$trials)),
               check.names = FALSE, stringsAsFactors = FALSE)
  })
  output$rel_table <- renderTable(rel_df(), align = 'lrrr')

  # ------------------------------------------------------------- downloads
  stamp_name <- function(ext) paste0('tennis_', input$stroke, '_', format(Sys.time(), '%Y%m%d_%H%M'), ext)

  T_ <- function(key) TXT[[if (identical(input$lang, 'zh')) 'zh' else 'en']][[key]]
  esc <- htmltools::htmlEscape
  report_head <- function(title) {
    level_label <- names(LEVELS)[LEVELS == input$level]
    c('<!doctype html><html><head><meta charset="utf-8"><title>AI Tennis Coach report</title><style>',
      'body{font-family:-apple-system,"PingFang SC","Microsoft YaHei",Segoe UI,Helvetica,Arial,sans-serif;max-width:980px;margin:2em auto;line-height:1.55;color:#222;padding:0 1em}',
      'h1{margin-bottom:0}h2{border-bottom:2px solid #e5e5e5;padding-bottom:4px;margin-top:1.6em}',
      'table{border-collapse:collapse;margin:0.8em 0;font-size:92%}td,th{border:1px solid #d0d0d0;padding:4px 8px;text-align:left}',
      'th{background:#f2f4f7}.note{color:#666;font-size:90%}.good{color:#2e7d32}',
      '@media print{body{margin:0;max-width:none}h2{page-break-after:avoid}img,table{page-break-inside:avoid}}',
      '</style></head><body>',
      sprintf('<h1>%s</h1><p class="note">AI Tennis Coach v3 &middot; %s &middot; %s: %s</p>',
              esc(title), format(Sys.time(), '%d %B %Y, %H:%M'), T_('level'), esc(level_label)),
      if (nzchar(trimws(input$goals))) sprintf('<p><strong>%s:</strong> %s</p>', T_('goal'), esc(input$goals)))
  }
  findings_html <- function(res) {
    cues <- as_chr(res$cues); good <- as_chr(res$strengths)
    c(sprintf('<h2>%s</h2>', T_('findings')),
      if (length(cues)) c('<ol>', paste0('<li>', esc(cues), '</li>'), '</ol>') else sprintf('<p>%s</p>', T_('none')),
      if (length(good)) c(sprintf('<p><strong>%s</strong></p><ul class="good">', T_('close')),
                          paste0('<li>', esc(good), '</li>'), '</ul>'))
  }
  ai_html <- function(advice, fitness) c(
    if (!is.null(advice)) c(sprintf('<h2>%s</h2>', T_('advice')), md_html(advice)),
    if (!is.null(fitness)) c(sprintf('<h2>%s</h2>', T_('fitness')), md_html(fitness)))
  report_foot <- function() sprintf('<p class="note">%s</p></body></html>', T_('footer'))
  stroke_title <- function() paste(names(STROKES)[STROKES == input$stroke], T_('analysis'))

  build_report <- function() {
    parts <- report_head(stroke_title())
    cmp <- state$motion
    if (isTRUE(cmp$match)) {
      parts <- c(parts, findings_html(cmp), ai_html(state$advice, state$fitness))
      if (!is.null(state$answer))
        parts <- c(parts, sprintf('<h2>%s</h2><p><em>%s</em></p>', T_('followup'), esc(input$question)), md_html(state$answer))
      parts <- c(parts, sprintf('<h2>%s</h2>', T_('contact')), img64(state$pro_video$contact_image),
                 img64(state$student_video$contact_image),
                 sprintf('<h2>%s</h2>', T_('measures')), html_table(metrics_df(cmp)),
                 sprintf('<h2>%s</h2>', T_('angles')), html_table(angles_df(cmp)))
      joints <- as_chr(cmp$compared)
      tmp <- tempfile(fileext = '.png')
      png(tmp, width = 1200, height = 330 * ceiling(length(joints) / 3), res = 110)
      op <- par(mfrow = c(ceiling(length(joints) / 3), 3), mar = c(4, 4, 2.5, 1))
      for (j in joints) draw_angle_plot(cmp, j)
      par(op); dev.off()
      parts <- c(parts, sprintf('<h2>%s</h2>', T_('curves')), img64(tmp, 'image/png', '100%'))
      w <- all_warnings()
      if (length(w)) parts <- c(parts, sprintf('<h2>%s</h2><ul>', T_('notes')), paste0('<li>', esc(w), '</li>'), '</ul>')
    }
    if (isTRUE(state$frame_result$match)) parts <- c(parts, frame_section())
    enc2utf8(paste(c(parts, report_foot()), collapse = '\n'))
  }
  frame_section <- function() {
    fr <- state$frame_result
    phase_label <- names(PHASES)[PHASES == (fr$phase %||% 'contact')]
    c(sprintf('<h2>%s</h2><p><strong>%s:</strong> %s</p>', T_('frames'), T_('phase'), esc(phase_label)),
      img64(fr$professional_annotated), img64(fr$student_annotated),
      sprintf('<h2>%s</h2>', T_('frame_angles')), html_table(angles_df(fr)),
      if (identical(fr$phase %||% 'contact', 'contact')) findings_html(fr),
      ai_html(state$frame_advice, state$frame_fitness),
      if (length(as_chr(fr$warnings))) c(sprintf('<h2>%s</h2><ul>', T_('notes')), paste0('<li>', esc(as_chr(fr$warnings)), '</li>'), '</ul>'),
      if (!is.null(state$reliability)) c(sprintf('<h2>%s</h2>', T_('reliability')), html_table(rel_df())))
  }
  build_frame_report <- function() {
    enc2utf8(paste(c(report_head(paste(names(STROKES)[STROKES == input$stroke], '\u2013', T_('frames'))),
                     frame_section(), report_foot()), collapse = '\n'))
  }
  has_results <- function() !is.null(state$motion) || !is.null(state$frame_result)

  output$dl_report <- downloadHandler(
    filename = function() stamp_name('.html'),
    content = function(file) {
      if (!has_results()) { writeLines('<p>Run an analysis first.</p>', file); return() }
      writeLines(build_report(), file, useBytes = TRUE)
    })
  output$dl_frame_report <- downloadHandler(
    filename = function() stamp_name('_frames.html'),
    content = function(file) {
      if (!isTRUE(state$frame_result$match)) { writeLines('<p>Compare two still frames first.</p>', file); return() }
      writeLines(build_frame_report(), file, useBytes = TRUE)
    })
  output$dl_csv <- downloadHandler(
    filename = function() stamp_name('.csv'),
    content = function(file) {
      cmp <- state$motion
      if (isTRUE(cmp$match)) {
        m <- metrics_df(cmp); a <- angles_df(cmp)
        long <- rbind(data.frame(Section = 'Whole-stroke measure', Item = m$Measure, Professional = m$Professional,
                                 Student = m$Student, Difference = m$`Student minus pro`, Unit = m$Unit),
                      data.frame(Section = 'Angle at contact', Item = a$Angle, Professional = a$Professional,
                                 Student = a$Student, Difference = a$`Student minus pro`, Unit = 'degrees'))
        write.csv(long, file, row.names = FALSE)
      } else if (isTRUE(state$frame_result$match)) {
        write.csv(angles_df(state$frame_result), file, row.names = FALSE)
      } else writeLines('Run an analysis first.', file)
    })
  output$dl_bundle <- downloadHandler(
    filename = function() stamp_name('.zip'),
    content = function(file) {
      dir <- file.path(tempdir(), paste0('bundle_', token)); unlink(dir, recursive = TRUE)
      dir.create(dir)
      writeLines(build_report(), file.path(dir, 'report.html'), useBytes = TRUE)
      cmp <- state$motion
      if (isTRUE(cmp$match)) {
        write.csv(metrics_df(cmp), file.path(dir, 'stroke_measures.csv'), row.names = FALSE)
        write.csv(angles_df(cmp), file.path(dir, 'contact_angles.csv'), row.names = FALSE)
        write.csv(curves_df(cmp), file.path(dir, 'angle_curves.csv'), row.names = FALSE)
        for (f in c(state$pro_video$annotated_video, state$student_video$annotated_video, state$sbs,
                    state$pro_video$contact_image, state$student_video$contact_image))
          if (!is.null(f) && file.exists(f)) file.copy(f, dir)
      }
      if (isTRUE(state$frame_result$match)) write.csv(angles_df(state$frame_result), file.path(dir, 'frame_angles.csv'), row.names = FALSE)
      for (x in list(c('advice', 'ai_technique_advice.md'), c('fitness', 'ai_injury_prevention_fitness.md'),
                     c('frame_advice', 'ai_frames_technique_advice.md'), c('frame_fitness', 'ai_frames_injury_prevention_fitness.md')))
        if (!is.null(state[[x[1]]])) writeLines(enc2utf8(state[[x[1]]]), file.path(dir, x[2]), useBytes = TRUE)
      if (isTRUE(state$frame_result$match)) writeLines(build_frame_report(), file.path(dir, 'still_frame_report.html'), useBytes = TRUE)
      tmpzip <- tempfile(fileext = '.zip')
      utils::zip(tmpzip, list.files(dir, full.names = TRUE), flags = '-j -q')
      file.copy(tmpzip, file, overwrite = TRUE)
    })
}

shinyApp(ui, server)
