# AI Tennis Coach — version 2

R Shiny app that compares a student's tennis stroke with a professional's using
MediaPipe Tasks **PoseLandmarker** 3D world landmarks.

## What is new in version 2

| Area | Change |
|---|---|
| Handedness | Triple-product **chirality check** (sign of det[u; v; n]); left-handers are **mirrored** into a virtual right-hander (reflect + swap labels) before comparing; left/right label mix-ups are detected and corrected. |
| Signed results | Differences are **student minus professional**, so they say *straighter* or *more bent*, not just "different". |
| Motion analysis | Whole videos at up to 60 fps in MediaPipe VIDEO mode, **contact estimated** from peak hitting-wrist speed, strokes **aligned in time with dynamic time warping** (DTW). |
| New angles | Hitting wrist, **hip–shoulder separation** (signed, horizontal plane), trunk tilt, with all angles labelled relative to the hitting arm. |
| Confidence | Landmarks below 0.5 visibility are excluded from every angle. |
| Smoothing | Savitzky–Golay filter on landmark trajectories (no SciPy needed). |
| Validation | `tests/test_geometry.py`: 17 tests proving the invariance claims on synthetic skeletons, plus a **reliability check** button that re-detects a frame under small crops. |
| Coaching | Rule-based cues first; the AI prompt receives signed values, the stroke phase and the cues, and is told the numbers are differences **between players, not left/right asymmetry**. |
| Engineering | Detector reused for still frames; private folder per browser session; frame extraction in Python (FFmpeg now optional); one pinned Python version. |
| Interface | Annotated videos (hitting arm in green, contact marked), contact frames, angle-over-time plot, downloadable HTML report. |

## Installation (Mac / RStudio)

1. Optional but recommended: `brew install ffmpeg` (re-encodes annotated videos so browsers play them).
2. Unzip, open the folder in RStudio, choose **Session → Restart R**.
3. Run `source('setup.R')` once. It creates the `aitenniscoach` virtualenv (Python 3.11),
   installs MediaPipe 1.1.1, OpenCV, NumPy, requests and pytest, and downloads the model
   to `models/pose_landmarker_heavy.task`.
   If the download fails, save this file there manually:
   https://storage.googleapis.com/mediapipe-models/pose_landmarker/pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task
4. **Restart R**, then `shiny::runApp('.')`.

`OPENAI_API_KEY` is needed only for the AI advice buttons (set it in `~/.Renviron`).

## Usage

1. Upload the professional and student videos. Leave **Hitting arm** on *Detect automatically*
   or set it.
   Uploaded videos appear straight away in the Motion tab.
2. **Analyse and compare strokes** (recommended). You get annotated videos, the two contact
   frames, a table of signed differences at contact and averaged over the aligned stroke,
   and a plot of any angle over time.
3. **Still frames** (optional): extract frames, pick one of each, compare. Quicker, but the
   two frames may not be the same moment of the stroke.
4. **Reliability check**: shows how much each angle moves when the same frame is re-detected.
5. **Coaching tab**: rule-based observations, then optional AI advice.
6. **Download report** saves everything as one HTML file.

## The mathematics

* **Angles** come from normalised dot products of 3D joint vectors. They are unchanged by
  translation, uniform scaling and rotation, because a rotation Q satisfies QᵀQ = I and so
  preserves dot products.
* **Reflections also satisfy QᵀQ = I**, so angles alone cannot tell a left-hander from a
  mirrored right-hander.
* **Chirality**: with u = right shoulder − left shoulder, v = trunk axis and n = nose direction,
  the sign of the triple product (u × v)·n = det[u; v; n] is kept by rotations (det +1) and
  flipped by reflections (det −1). A left/right **label swap** also flips it (u → −u), so a
  mismatch between the two players reveals a mirrored video or a mislabelled skeleton.
* **Mirroring** a left-hander means reflecting the geometry *and* swapping labels. Two flips
  cancel, so the result is again a correctly labelled body with the same chirality.
* **Hip–shoulder separation** is a signed angle in the horizontal plane; its sign comes from a
  triple product with the vertical, so it flips under reflection while its size does not.
* **Contact** is estimated as the frame of peak hitting-wrist speed relative to the hips.
* **DTW** finds the monotone matching of the two angle sequences (z-scored per joint) with the
  least total distance, so a slower swing is compared phase by phase, not clock time.

## Tests

```
~/.virtualenvs/aitenniscoach/bin/python -m pytest tests      # or: python tests/test_geometry.py
```

The tests need only NumPy. They check rotation, scaling and translation invariance, that
reflections preserve angles but flip chirality, that label swaps flip chirality, that
mirroring twice is the identity, smoothing, gap filling, contact and hitting-arm detection,
and that DTW recovers a known time warp.

## Code map

* `app.R` — Shiny interface.
* `bin/geometry.py` — all the mathematics, pure NumPy (tested).
* `bin/pose_analysis.py` — MediaPipe detection, frame and video workflows, DTW comparison, reliability check.
* `bin/coaching.py` — rule thresholds and cues, and the prompt for the AI coach.
* `bin/chatgpt_request.py` — optional OpenAI request.
* `tests/test_geometry.py` — invariance and algorithm tests.
* `setup.R` — environment and model setup.

## Limitations

* MediaPipe's 3D world coordinates are estimated from a single camera, so depth is the least
  reliable direction; film from a similar angle for both players.
* Contact from peak wrist speed is an approximation (peak racket-head speed is close to, not
  exactly at, impact).
* Rule thresholds (15° for most joints) are starting points, not established norms.
* The sample professional clip is low resolution (360×640), which lowers landmark accuracy.
  It is broadcast footage: fine for a private project, but do not redistribute it if the app
  is deployed publicly. Students' videos are personal data; get consent before sharing.
* Not an injury assessment.

## Testing status

Tested in the packaging environment: the 17 geometry tests pass, and the full Python pipeline
(frame extraction, video analysis, annotated video with H.264 re-encoding, mirroring, chirality
correction, DTW comparison, reliability check) was run end to end on the sample videos with a
**simulated** pose detector. A mirrored, delayed copy of the same stroke was correctly detected
as left-handed, mirrored, aligned and gave zero differences.
**Not yet run:** real MediaPipe inference (the model could not be downloaded there) and the
Shiny interface (R was not available). Run both on the Mac before relying on the app.

## Troubleshooting

* *Missing model*: the app shows a red box with a **Download pose model** button and the exact folder it
  expects. The model is looked for in `models/` inside the app folder, then in `models/` of the working
  directory, then `~/models`.
* *Video does not play*: the app converts each upload into a browser-friendly copy (H.264, index at
  the start of the file) using FFmpeg. Phone videos often store the index at the end of the file, and
  iPhone videos may be HEVC, so without FFmpeg they may not play. Install it with `brew install ffmpeg`
  and restart R; the app also finds FFmpeg in `/opt/homebrew/bin` when RStudio cannot see your PATH.
  If videos still do not play in the RStudio window, click **Open in Browser** at the top of the app.
* *Python errors after updating*: restart R before `runApp`; never call `use_python()` after Python has started.
