# AI Tennis Coach - R Shiny entry point.
# Launch from the project folder with shiny::runApp(".").
library(shiny)
library(reticulate)

# Select Python BEFORE source_python() or any other Python call (set up by setup.R).
reticulate::use_virtualenv('aitenniscoach', required = TRUE)
options(shiny.maxRequestSize = 200 * 1024^2)

source_python('bin/pose_analysis.py')
source_python('bin/chatgpt_request.py')

# The pose model lives in models/ inside this app's folder (downloaded, not in the ZIP).
MODEL_FILE <- file.path(normalizePath('.'), 'models', 'pose_landmarker_heavy.task')
MODEL_URL <- paste0('https://storage.googleapis.com/mediapipe-models/pose_landmarker/',
                    'pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task')
if (file.exists(MODEL_FILE)) set_model_path(MODEL_FILE)

# FFmpeg makes videos playable in browsers. RStudio on a Mac often does not see the
# Homebrew PATH, so look in the usual install locations as well.
find_ffmpeg <- function() {
  hits <- c(unname(Sys.which('ffmpeg')), '/opt/homebrew/bin/ffmpeg', '/usr/local/bin/ffmpeg', '/usr/bin/ffmpeg')
  hits <- hits[nzchar(hits) & file.exists(hits)]
  if (length(hits)) hits[1] else ''
}
FFMPEG <- find_ffmpeg()

# Browser-friendly copy of an upload: H.264 + AAC with the index at the start
# ('faststart'). Phone videos often store the index at the END of the file,
# which stops them playing in a browser until the whole file has downloaded,
# and iPhone videos may be HEVC, which Chrome cannot play at all.
make_preview <- function(src, dst) {
  if (!nzchar(FFMPEG)) return(FALSE)
  run <- function(args) {
    out <- suppressWarnings(system2(FFMPEG, c('-hide_banner', '-loglevel', 'error', '-y', '-i', shQuote(src),
                                              args, shQuote(dst)), stdout = TRUE, stderr = TRUE))
    is.null(attr(out, 'status')) && file.exists(dst) && file.size(dst) > 0
  }
  run(c('-vf', shQuote('scale=trunc(iw/2)*2:trunc(ih/2)*2'), '-c:v', 'libx264', '-preset', 'veryfast',
        '-crf', '23', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-movflags', '+faststart')) ||
    run(c('-c', 'copy', '-movflags', '+faststart'))
}
DEG <- '\u00b0'

# ------------------------------------------------------------------ helpers
as_chr <- function(x) if (is.null(x)) character(0) else as.character(unlist(x))

# Python None arrives as NULL; turn a named list into a numeric vector with NA.
num <- function(x) {
  if (is.null(x) || !length(x)) return(numeric(0))
  vapply(x, function(v) if (is.null(v) || !length(v)) NA_real_ else as.numeric(v), numeric(1))
}

fmt_signed <- function(x) ifelse(is.na(x), 'n/a', sprintf('%+.1f', x))

pose_panel <- function(title, output_id) {
  column(6, h4(title), div(class = 'pose-image', imageOutput(output_id, height = 'auto')))
}

draw_angle_plot <- function(cmp, joint) {
  t <- as.numeric(cmp$time)
  p <- as.numeric(cmp$pro_series[[joint]])
  s <- as.numeric(cmp$student_series[[joint]])
  yl <- range(c(p, s), na.rm = TRUE)
  if (!all(is.finite(yl))) yl <- c(0, 180)
  plot(t, p, type = 'l', lwd = 2, col = '#1f77b4', ylim = yl,
       xlab = "Time relative to the professional's contact (s)",
       ylab = paste0('Angle (', DEG, ')'), main = joint)
  lines(t, s, lwd = 2, col = '#d62728', lty = 2)
  abline(v = 0, col = 'grey50', lty = 3)
  legend('topleft', c('Professional', 'Student (time-aligned by DTW)'),
         col = c('#1f77b4', '#d62728'), lty = c(1, 2), lwd = 2, bty = 'n')
}

html_table <- function(df) {
  esc <- htmltools::htmlEscape
  head <- paste0('<tr>', paste0('<th>', esc(names(df)), '</th>', collapse = ''), '</tr>')
  rows <- apply(df, 1, function(r) paste0('<tr>', paste0('<td>', esc(r), '</td>', collapse = ''), '</tr>'))
  paste0('<table>', head, paste(rows, collapse = ''), '</table>')
}

img64 <- function(path, type = 'image/jpeg') {
  if (is.null(path) || !file.exists(path)) return('')
  raw <- readBin(path, 'raw', file.info(path)$size)
  sprintf('<img src="data:%s;base64,%s" style="max-width:48%%;margin:4px">', type, jsonlite::base64_enc(raw))
}

# ----------------------------------------------------------------------- UI
ui <- fluidPage(
  tags$head(tags$style(HTML('
    .pose-image { width:100%; max-width:520px; aspect-ratio:1/1;
                  border:1px solid #ddd; background:#f5f5f5; }
    .pose-image img { width:100% !important; height:100% !important; object-fit:contain; }
    .pose-image .shiny-image-output { width:100%; height:100%; }
    video { width:100%; max-width:520px; background:#000; }
    .note { color:#666; font-size:90%; }
  '))),
  titlePanel('\U0001F3BE AI Tennis Coach'),
  sidebarLayout(
    sidebarPanel(
      h4('Professional'),
      fileInput('pro_video', 'Upload professional MP4', accept = c('.mp4', '.mov')),
      selectInput('pro_hand', 'Hitting arm', c('Detect automatically' = 'auto', 'Right' = 'right', 'Left' = 'left')),
      h4('Student'),
      fileInput('student_video', 'Upload student MP4', accept = c('.mp4', '.mov')),
      selectInput('student_hand', 'Hitting arm', c('Detect automatically' = 'auto', 'Right' = 'right', 'Left' = 'left')),
      hr(),
      h4('1. Motion analysis (recommended)'),
      sliderInput('target_fps', 'Analysis frame rate (fps)', min = 10, max = 60, value = 30, step = 5),
      actionButton('analyse', 'Analyse and compare strokes', class = 'btn-primary'),
      hr(),
      h4('2. Still frames'),
      numericInput('frame_fps', 'Frames per second to extract', value = 5, min = 1, max = 30),
      actionButton('extract', 'Extract and annotate frames'),
      uiOutput('pro_selector'),
      uiOutput('student_selector'),
      actionButton('compare_frames', 'Compare selected frames'),
      actionButton('reliability', 'Reliability check'),
      p(class = 'note', 'The reliability check re-detects the selected student frame under small crops.'),
      hr(),
      h4('3. Coaching'),
      actionButton('advice', 'Get AI coaching advice'),
      textAreaInput('question', 'Other coaching question', rows = 3),
      actionButton('ask', 'Ask AI'),
      hr(),
      downloadButton('report', 'Download report (HTML)')
    ),
    mainPanel(
      uiOutput('model_banner'),
      tabsetPanel(id = 'tabs',
        tabPanel('Motion',
          fluidRow(column(6, h4('Professional'), uiOutput('pro_video_ui')),
                   column(6, h4('Student'), uiOutput('student_video_ui'))),
          fluidRow(pose_panel('Professional at contact', 'pro_contact'),
                   pose_panel('Student at contact', 'student_contact')),
          h4('Summary'),
          verbatimTextOutput('motion_summary'),
          h4(paste0('Signed differences: student minus professional (', DEG, ')')),
          p(class = 'note', 'Elbow, knee, wrist: positive = student straighter. Shoulder: positive = arm further from the body.'),
          tableOutput('motion_table'),
          selectInput('plot_joint', 'Angle to plot over the stroke', choices = character(0)),
          plotOutput('angle_plot', height = '340px')
        ),
        tabPanel('Still frames',
          fluidRow(pose_panel('Professional', 'pro_image'),
                   pose_panel('Student', 'student_image')),
          h4(paste0('Joint angles (', DEG, ')')),
          tableOutput('frame_table'),
          verbatimTextOutput('frame_notes')
        ),
        tabPanel('Coaching',
          h4('Rule-based observations'),
          uiOutput('cues_ui'),
          h4('AI coaching advice'),
          verbatimTextOutput('advice_text'),
          h4('Answer to your question'),
          verbatimTextOutput('answer_text')
        ),
        tabPanel('Reliability',
          p('The same student frame is re-detected under several small random crops and shifts.',
            'The standard deviation (SD) estimates measurement error: a difference between',
            'players smaller than about twice the SD may just be noise.'),
          tableOutput('rel_table')
        ),
        tabPanel('About',
          p('Joint angles come from normalised dot products of 3D world landmarks, so they ignore',
            'position, size and camera rotation. Reflections preserve them too, so the app checks',
            'handedness with the sign of a triple product and mirrors left-handers before comparing.'),
          p('Motion analysis estimates contact from peak hitting-wrist speed and aligns the two strokes',
            'with dynamic time warping. All results are estimates from video and are not an injury assessment.')
        )
      )
    )
  )
)

# ------------------------------------------------------------------- server
server <- function(input, output, session) {
  # A private folder per browser session, so two users never overwrite each other.
  token <- gsub('[^A-Za-z0-9]', '', session$token)
  workdir <- file.path(tempdir(), paste0('tennis_', token))
  dir.create(workdir, recursive = TRUE, showWarnings = FALSE)
  res_prefix <- paste0('media_', token)
  addResourcePath(res_prefix, workdir)
  session$onSessionEnded(function() {
    unlink(workdir, recursive = TRUE)
    try(removeResourcePath(res_prefix), silent = TRUE)
  })

  path <- function(...) file.path(workdir, ...)
  pro_upload <- path('pro_upload.mp4')
  stu_upload <- path('student_upload.mp4')
  pro_preview <- path('pro_preview.mp4')
  stu_preview <- path('student_preview.mp4')

  # Show the browser-friendly preview if one was made, otherwise the raw upload.
  preview_file <- function(preview, upload) if (file.exists(preview)) preview else upload
  prepare_preview <- function(upload, preview) {
    unlink(preview)
    if (nzchar(FFMPEG)) {
      withProgress(message = 'Preparing video preview', value = 0.5, {
        if (!make_preview(upload, preview))
          showNotification('Could not convert this video for the browser; showing the original file.', type = 'warning')
      })
    }
  }

  state <- reactiveValues(pro_frames = NULL, student_frames = NULL, frame_result = NULL,
                          pro_video = NULL, student_video = NULL, motion = NULL,
                          reliability = NULL, advice = NULL, answer = NULL,
                          active = 'none', stamp = 0, upload_stamp = 0)

  # ------------------------------------------------------------- pose model
  model_found <- reactiveVal(nzchar(find_model()))
  output$model_banner <- renderUI({
    if (model_found()) return(NULL)
    div(style = 'background:#fdecea;border:1px solid #f5c2c0;padding:12px;margin:10px 0;border-radius:6px',
        strong('The pose model is not installed yet.'),
        p('The app needs pose_landmarker_heavy.task in:', code(dirname(MODEL_FILE))),
        actionButton('download_model', 'Download pose model (about 30 MB)', class = 'btn-danger'))
  })
  observeEvent(input$download_model, {
    withProgress(message = 'Downloading the pose model', value = 0.3, {
      tryCatch({
        dir.create(dirname(MODEL_FILE), recursive = TRUE, showWarnings = FALSE)
        options(timeout = max(900, getOption('timeout')))   # a 30 MB file can exceed the 60 s default
        download.file(MODEL_URL, MODEL_FILE, mode = 'wb', quiet = TRUE)
        if (!file.exists(MODEL_FILE) || file.size(MODEL_FILE) < 1e6) stop('The downloaded file is too small.')
        set_model_path(MODEL_FILE)
        model_found(nzchar(find_model()))
        showNotification('Pose model installed.', type = 'message')
      }, error = function(e) {
        if (file.exists(MODEL_FILE) && file.size(MODEL_FILE) < 1e6) unlink(MODEL_FILE)
        showNotification(paste('Download failed:', conditionMessage(e),
                               '- save the file manually into', dirname(MODEL_FILE)),
                         type = 'error', duration = NULL)
      })
    })
  })
  need_model <- function() {
    if (model_found()) return(TRUE)
    showNotification('Install the pose model first (red box at the top).', type = 'error')
    FALSE
  }

  notify_error <- function(e) showNotification(conditionMessage(e), type = 'error', duration = NULL)

  # Use the user's choice, else the arm detected in motion analysis, else 'auto'.
  hand_for <- function(choice, analysed) {
    if (!identical(choice, 'auto')) return(choice)
    if (!is.null(analysed)) return(as.character(analysed$hitting_arm))
    'auto'
  }

  reset <- function() {
    state$pro_frames <- NULL; state$student_frames <- NULL; state$frame_result <- NULL
    state$pro_video <- NULL; state$student_video <- NULL; state$motion <- NULL
    state$reliability <- NULL; state$advice <- NULL; state$active <- 'none'
  }
  observeEvent(input$pro_video, {
    file.copy(input$pro_video$datapath, pro_upload, overwrite = TRUE)
    prepare_preview(pro_upload, pro_preview)
    reset(); state$upload_stamp <- as.numeric(Sys.time())
  })
  observeEvent(input$student_video, {
    file.copy(input$student_video$datapath, stu_upload, overwrite = TRUE)
    prepare_preview(stu_upload, stu_preview)
    reset(); state$upload_stamp <- as.numeric(Sys.time())
  })

  # ---------------------------------------------------------- motion analysis
  observeEvent(input$analyse, {
    req(input$pro_video, input$student_video)
    if (!need_model()) return()
    withProgress(message = 'Analysing strokes', value = 0, {
      tryCatch({
        incProgress(0.05, detail = 'professional video')
        pv <- analyse_video(pro_upload, path('motion'), 'pro', input$pro_hand,
                            as.integer(input$target_fps), 450L, FFMPEG)
        incProgress(0.45, detail = 'student video')
        sv <- analyse_video(stu_upload, path('motion'), 'student', input$student_hand,
                            as.integer(input$target_fps), 450L, FFMPEG)
        incProgress(0.4, detail = 'aligning the strokes in time')
        cmp <- compare_videos(pv$npz, sv$npz)
        state$pro_video <- pv; state$student_video <- sv; state$motion <- cmp
        state$stamp <- as.numeric(Sys.time())
        state$active <- 'motion'; state$advice <- NULL
        if (isTRUE(cmp$match)) {
          joints <- as_chr(cmp$compared)
          updateSelectInput(session, 'plot_joint', choices = joints,
                            selected = if ('Hitting elbow' %in% joints) 'Hitting elbow' else joints[1])
        } else {
          showNotification(cmp$message, type = 'warning')
        }
        updateTabsetPanel(session, 'tabs', selected = 'Motion')
      }, error = notify_error)
    })
  })

  # Before analysis: the uploaded video. After analysis: the annotated one.
  video_tag <- function(v, file, upload, uploaded) {
    if (!is.null(v)) {
      src <- paste0(res_prefix, '/motion/', file, '?v=', state$stamp)
      note <- 'Annotated: hitting arm in green, estimated contact marked.'
    } else if (isTRUE(uploaded) && file.exists(upload)) {
      src <- paste0(res_prefix, '/', basename(upload), '?v=', state$upload_stamp)
      note <- 'Uploaded video. Run motion analysis to add the skeleton.'
    } else {
      return(p(class = 'note', 'Upload a video to see it here.'))
    }
    tagList(tags$video(src = src, controls = NA, preload = 'metadata'),
            p(class = 'note', note,
              if (!nzchar(FFMPEG)) 'FFmpeg was not found, so videos may not play: install it with brew install ffmpeg and restart R.'))
  }
  output$pro_video_ui <- renderUI(video_tag(state$pro_video, 'pro_annotated.mp4',
                                            preview_file(pro_preview, pro_upload), !is.null(input$pro_video)))
  output$student_video_ui <- renderUI(video_tag(state$student_video, 'student_annotated.mp4',
                                                preview_file(stu_preview, stu_upload), !is.null(input$student_video)))

  contact_image <- function(v) {
    req(v)
    list(src = normalizePath(v$contact_image), contentType = 'image/jpeg', width = '100%')
  }
  output$pro_contact <- renderImage(contact_image(state$pro_video), deleteFile = FALSE)
  output$student_contact <- renderImage(contact_image(state$student_video), deleteFile = FALSE)

  motion_warnings <- reactive({
    unique(c(as_chr(state$pro_video$warnings), as_chr(state$student_video$warnings),
             as_chr(state$motion$warnings)))
  })

  output$motion_summary <- renderText({
    req(state$motion)
    pv <- state$pro_video; sv <- state$student_video; cmp <- state$motion
    lines <- c(
      sprintf('Professional: %s-handed, %d frames at %.0f fps, contact at %.2f s, pose found in %.0f%% of frames',
              pv$hitting_arm, as.integer(pv$n_frames), pv$fps, pv$contact_time, 100 * pv$detected_fraction),
      sprintf('Student:      %s-handed, %d frames at %.0f fps, contact at %.2f s, pose found in %.0f%% of frames',
              sv$hitting_arm, as.integer(sv$n_frames), sv$fps, sv$contact_time, 100 * sv$detected_fraction))
    if (isTRUE(cmp$match)) {
      lines <- c(lines, sprintf('Average DTW distance per aligned step: %.2f (0 = identical timing-adjusted motion)',
                                cmp$dtw_cost),
                 sprintf('Triple-product chirality: professional %+d, student %+d',
                         as.integer(cmp$info$chirality_pro), as.integer(cmp$info$chirality_student)))
    } else {
      lines <- c(lines, cmp$message)
    }
    w <- motion_warnings()
    if (length(w)) lines <- c(lines, '', 'Notes:', paste('-', w))
    paste(lines, collapse = '\n')
  })

  motion_df <- reactive({
    cmp <- state$motion
    req(isTRUE(cmp$match))
    data.frame(Angle = names(cmp$contact_diffs),
               `At contact` = fmt_signed(num(cmp$contact_diffs)),
               `Average over stroke` = fmt_signed(num(cmp$stroke_mean_diffs)),
               `Average size of difference` = ifelse(is.na(num(cmp$stroke_abs_diffs)), 'n/a',
                                                     sprintf('%.1f', num(cmp$stroke_abs_diffs))),
               check.names = FALSE, stringsAsFactors = FALSE)
  })
  output$motion_table <- renderTable(motion_df(), align = 'lrrr')

  output$angle_plot <- renderPlot({
    cmp <- state$motion
    req(isTRUE(cmp$match), input$plot_joint, input$plot_joint %in% as_chr(cmp$compared))
    draw_angle_plot(cmp, input$plot_joint)
  })

  # -------------------------------------------------------------- still frames
  observeEvent(input$extract, {
    req(input$pro_video, input$student_video)
    if (!need_model()) return()
    withProgress(message = 'Extracting and annotating frames', value = 0, {
      tryCatch({
        fps <- max(1, as.numeric(input$frame_fps))
        state$pro_frames <- as_chr(extract_frames(pro_upload, path('pro_frames'), fps))
        incProgress(0.2)
        state$student_frames <- as_chr(extract_frames(stu_upload, path('student_frames'), fps))
        incProgress(0.2, detail = 'detecting poses')
        annotate_all_frames(path('pro_frames'), path('pro_frames_pose'),
                            hand_for(input$pro_hand, state$pro_video))
        incProgress(0.3)
        annotate_all_frames(path('student_frames'), path('student_frames_pose'),
                            hand_for(input$student_hand, state$student_video))
        state$frame_result <- NULL
        updateTabsetPanel(session, 'tabs', selected = 'Still frames')
        showNotification(sprintf('%d professional and %d student frames ready',
                                 length(state$pro_frames), length(state$student_frames)), type = 'message')
      }, error = notify_error)
    })
  })

  output$pro_selector <- renderUI({
    req(state$pro_frames)
    selectInput('pro_choice', 'Professional frame', choices = state$pro_frames)
  })
  output$student_selector <- renderUI({
    req(state$student_frames)
    selectInput('student_choice', 'Student frame', choices = state$student_frames)
  })

  frame_image <- function(choice, annotated_dir, original_dir) {
    req(choice)
    annotated <- path(annotated_dir, choice)
    file <- if (file.exists(annotated)) annotated else path(original_dir, choice)
    req(file.exists(file))
    list(src = normalizePath(file), contentType = 'image/jpeg', width = '100%')
  }
  output$pro_image <- renderImage(frame_image(input$pro_choice, 'pro_frames_pose', 'pro_frames'), deleteFile = FALSE)
  output$student_image <- renderImage(frame_image(input$student_choice, 'student_frames_pose', 'student_frames'), deleteFile = FALSE)

  # Detection always runs on the ORIGINAL frames, never on annotated copies.
  observeEvent(input$compare_frames, {
    req(input$pro_choice, input$student_choice)
    tryCatch({
      res <- compare_frames(path('pro_frames', input$pro_choice),
                            path('student_frames', input$student_choice),
                            hand_for(input$pro_hand, state$pro_video),
                            hand_for(input$student_hand, state$student_video),
                            path('comparison'))
      state$frame_result <- res
      state$active <- 'frame'; state$advice <- NULL
      if (!isTRUE(res$match)) showNotification(res$message, type = 'warning')
    }, error = notify_error)
  })

  output$frame_table <- renderTable({
    res <- state$frame_result
    req(isTRUE(res$match))
    pa <- num(res$pro_angles); sa <- num(res$student_angles); d <- num(res$signed_diffs)
    data.frame(Angle = names(res$signed_diffs),
               Professional = ifelse(is.na(pa), 'n/a', sprintf('%.1f', pa)),
               Student = ifelse(is.na(sa), 'n/a', sprintf('%.1f', sa)),
               `Student minus professional` = fmt_signed(d),
               check.names = FALSE, stringsAsFactors = FALSE)
  }, align = 'lrrr')

  output$frame_notes <- renderText({
    res <- state$frame_result
    req(res)
    w <- as_chr(res$warnings)
    paste(c(res$message, 'Single frames may not show the same moment of the stroke; motion analysis is more reliable.',
            if (length(w)) c('', 'Notes:', paste('-', w))), collapse = '\n')
  })

  # --------------------------------------------------------------- reliability
  observeEvent(input$reliability, {
    req(input$student_choice)
    withProgress(message = 'Re-detecting the frame under small crops', value = 0.3, {
      tryCatch({
        state$reliability <- reliability_check(path('student_frames', input$student_choice),
                                               hand_for(input$student_hand, state$student_video), 10L)
        updateTabsetPanel(session, 'tabs', selected = 'Reliability')
      }, error = notify_error)
    })
  })
  output$rel_table <- renderTable({
    r <- state$reliability
    req(r)
    tab <- r$table
    m <- as.numeric(unlist(tab$Mean)); s <- as.numeric(unlist(tab$SD))
    data.frame(Angle = as_chr(tab$Angle),
               Mean = ifelse(is.finite(m), sprintf('%.1f', m), 'n/a'),
               SD = ifelse(is.finite(s), sprintf('%.1f', s), 'n/a'),
               `Detected in` = sprintf('%d of %d', as.integer(unlist(tab$Detected)), as.integer(r$trials)),
               check.names = FALSE, stringsAsFactors = FALSE)
  }, align = 'lrrr')

  # ------------------------------------------------------------------ coaching
  active_result <- reactive({
    if (identical(state$active, 'motion')) state$motion
    else if (identical(state$active, 'frame')) state$frame_result
    else NULL
  })

  output$cues_ui <- renderUI({
    res <- active_result()
    if (is.null(res) || !isTRUE(res$match))
      return(p(class = 'note', 'Run a motion analysis or a frame comparison first.'))
    cues <- as_chr(res$cues)
    src <- if (identical(state$active, 'motion')) 'motion analysis (at contact)' else 'selected frames'
    tagList(p(class = 'note', paste('Based on the', src, '- differences above the rule thresholds only.')),
            if (length(cues)) tags$ul(lapply(cues, tags$li))
            else p('No difference was large enough to flag.'))
  })

  observeEvent(input$advice, {
    res <- active_result()
    if (is.null(res) || !isTRUE(res$match)) {
      state$advice <- 'Run a motion analysis or a frame comparison first.'
      return()
    }
    withProgress(message = 'Asking the AI coach', value = 0.5, {
      state$advice <- tryCatch(chatgptquery(res$prompt),
                               error = function(e) paste('AI request failed:', conditionMessage(e)))
    })
    updateTabsetPanel(session, 'tabs', selected = 'Coaching')
  })
  observeEvent(input$ask, {
    req(nzchar(trimws(input$question)))
    res <- active_result()
    prompt <- if (!is.null(res) && isTRUE(res$match))
      paste0(res$prompt, '\n\nThe player now asks: ', input$question) else input$question
    withProgress(message = 'Asking the AI coach', value = 0.5, {
      state$answer <- tryCatch(chatgptquery(prompt),
                               error = function(e) paste('AI request failed:', conditionMessage(e)))
    })
    updateTabsetPanel(session, 'tabs', selected = 'Coaching')
  })
  output$advice_text <- renderText({ req(state$advice); state$advice })
  output$answer_text <- renderText({ req(state$answer); state$answer })

  # -------------------------------------------------------------------- report
  output$report <- downloadHandler(
    filename = function() paste0('tennis_report_', format(Sys.time(), '%Y%m%d_%H%M'), '.html'),
    content = function(file) {
      parts <- c('<!doctype html><html><head><meta charset="utf-8"><title>AI Tennis Coach report</title>',
                 '<style>body{font-family:sans-serif;max-width:960px;margin:2em auto;line-height:1.45}',
                 'table{border-collapse:collapse;margin:1em 0}td,th{border:1px solid #ccc;padding:4px 8px}',
                 'th{background:#f2f2f2}.note{color:#666}</style></head><body>',
                 '<h1>AI Tennis Coach report</h1>',
                 sprintf('<p class="note">Generated %s. Differences are student minus professional, in degrees, after matching handedness.</p>',
                         format(Sys.time(), '%d %B %Y %H:%M')))
      cmp <- state$motion
      if (isTRUE(cmp$match)) {
        parts <- c(parts, '<h2>Motion comparison</h2>',
                   img64(state$pro_video$contact_image), img64(state$student_video$contact_image),
                   html_table(motion_df()))
        tmp <- tempfile(fileext = '.png')
        png(tmp, width = 900, height = 450)
        draw_angle_plot(cmp, if (nzchar(input$plot_joint %||% '')) input$plot_joint else as_chr(cmp$compared)[1])
        dev.off()
        parts <- c(parts, img64(tmp, 'image/png'))
        w <- motion_warnings()
        if (length(w)) parts <- c(parts, '<h3>Notes</h3><ul>',
                                  paste0('<li>', htmltools::htmlEscape(w), '</li>'), '</ul>')
      }
      fr <- state$frame_result
      if (isTRUE(fr$match)) {
        d <- num(fr$signed_diffs)
        parts <- c(parts, '<h2>Selected frames</h2>',
                   img64(fr$professional_annotated), img64(fr$student_annotated),
                   html_table(data.frame(Angle = names(fr$signed_diffs), `Student minus professional` = fmt_signed(d),
                                         check.names = FALSE)))
      }
      res <- active_result()
      if (!is.null(res) && length(as_chr(res$cues)))
        parts <- c(parts, '<h2>Rule-based observations</h2><ul>',
                   paste0('<li>', htmltools::htmlEscape(as_chr(res$cues)), '</li>'), '</ul>')
      if (!is.null(state$advice))
        parts <- c(parts, '<h2>AI coaching advice</h2>',
                   paste0('<pre style="white-space:pre-wrap">', htmltools::htmlEscape(state$advice), '</pre>'))
      if (!is.null(state$reliability)) {
        tab <- state$reliability$table
        parts <- c(parts, '<h2>Reliability check</h2>',
                   html_table(data.frame(Angle = as_chr(tab$Angle),
                                         SD = sprintf('%.1f', as.numeric(unlist(tab$SD))),
                                         check.names = FALSE)))
      }
      parts <- c(parts, '<p class="note">Estimated from video; not an injury assessment.</p></body></html>')
      writeLines(enc2utf8(paste(parts, collapse = '\n')), file, useBytes = TRUE)
    }
  )
}

`%||%` <- function(a, b) if (is.null(a)) b else a

shinyApp(ui, server)
