# Run once in RStudio: source('setup.R')
# Installs Python dependencies into the dedicated 'aitenniscoach' environment
# and downloads the MediaPipe pose model. Close Shiny and restart R first.
install.packages(c('shiny', 'reticulate', 'jsonlite', 'htmltools'))
library(reticulate)

# One pinned Python version for the whole project (avoids 3.11/3.13 mix-ups).
PYTHON_VERSION <- '3.11'
if (!'aitenniscoach' %in% virtualenv_list()) {
  virtualenv_create('aitenniscoach', python = PYTHON_VERSION)
}
virtualenv_install('aitenniscoach', packages = c(
  'mediapipe==1.1.1', 'opencv-contrib-python', 'numpy', 'requests', 'pytest'
), pip_options = '--upgrade')

# Download the MediaPipe Tasks model (not included in the ZIP).
dir.create('models', showWarnings = FALSE)
model_file <- file.path('models', 'pose_landmarker_heavy.task')
model_url <- paste0(
  'https://storage.googleapis.com/mediapipe-models/pose_landmarker/',
  'pose_landmarker_heavy/float16/1/pose_landmarker_heavy.task')
if (!file.exists(model_file) || file.size(model_file) < 1000000) {
  tryCatch({
    download.file(model_url, model_file, mode = 'wb', quiet = FALSE)
    if (file.size(model_file) < 1000000) stop('Downloaded model is unexpectedly small')
  }, error = function(e) {
    if (file.exists(model_file)) unlink(model_file)
    warning(paste('Model download failed:', conditionMessage(e),
                  '\nSee README.md for manual download.'))
  })
}

if (!nzchar(Sys.which('ffmpeg')))
  message('Optional: install FFmpeg (brew install ffmpeg) so annotated videos play in the browser.')
cat('\nSetup finished. Restart R, then run shiny::runApp(".") from this folder.\n')
cat('To run the maths tests: in a terminal, ~/.virtualenvs/aitenniscoach/bin/python -m pytest tests\n')
