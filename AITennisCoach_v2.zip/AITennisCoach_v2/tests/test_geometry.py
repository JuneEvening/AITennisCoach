"""Tests for bin/geometry.py on synthetic skeletons.

Run from the project folder with either:
    python -m pytest tests
    python tests/test_geometry.py
No MediaPipe, camera or model file is needed.

These tests are the evidence for the mathematical claims in the project:
  * joint angles ignore translation, uniform scaling and rotation;
  * reflections ALSO preserve them (Q^T Q = I), so angles alone cannot see handedness;
  * the triple-product chirality flips under a reflection or a label swap,
    but not under rotation or a proper left/right mirror.
"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'bin'))
import geometry as g  # noqa: E402

RNG = np.random.default_rng(42)


def skeleton():
    """A plausible standing right-hander in MediaPipe world coordinates
    (metres, hips at origin, y down, person facing the camera so -z is forward)."""
    w = np.zeros((33, 3))
    w[g.NOSE] = (0.0, -0.62, -0.10)
    for i in range(1, 11):                      # face points around the nose
        side = -1 if i in (4, 5, 6, 8, 10) else 1
        w[i] = (side * 0.03 * (1 + (i % 3)), -0.65, -0.08)
    w[g.L_SHOULDER], w[g.R_SHOULDER] = (0.19, -0.45, 0.06), (-0.19, -0.45, -0.06)  # shoulders turned
    w[g.L_ELBOW], w[g.R_ELBOW] = (0.28, -0.20, 0.02), (-0.35, -0.30, -0.15)
    w[g.L_WRIST], w[g.R_WRIST] = (0.30, 0.02, -0.05), (-0.45, -0.25, -0.40)
    for i, base in [(17, g.L_WRIST), (19, g.L_WRIST), (21, g.L_WRIST)]:
        w[i] = w[base] + (0.02, 0.06, -0.01)
    for i, base in [(18, g.R_WRIST), (20, g.R_WRIST), (22, g.R_WRIST)]:
        w[i] = w[base] + (-0.03, 0.02, -0.07)
    w[g.L_HIP], w[g.R_HIP] = (0.10, 0.0, 0.0), (-0.10, 0.0, 0.0)
    w[g.L_KNEE], w[g.R_KNEE] = (0.14, 0.42, -0.08), (-0.13, 0.43, -0.05)
    w[g.L_ANKLE], w[g.R_ANKLE] = (0.15, 0.84, 0.02), (-0.15, 0.85, 0.03)
    w[29], w[30] = w[g.L_ANKLE] + (0, 0.04, 0.05), w[g.R_ANKLE] + (0, 0.04, 0.05)
    w[31], w[32] = w[g.L_ANKLE] + (0, 0.05, -0.12), w[g.R_ANKLE] + (0, 0.05, -0.12)
    return w


def random_rotation():
    """A random 3x3 rotation: orthogonal (Q^T Q = I) with determinant +1."""
    q, r = np.linalg.qr(RNG.normal(size=(3, 3)))
    q = q @ np.diag(np.sign(np.diag(r)))
    if np.linalg.det(q) < 0:
        q[:, 0] *= -1
    return q


def angles_close(a, b, names=None, tol=1e-6):
    for n in names or g.ANGLE_NAMES:
        assert abs(a[n] - b[n]) < tol, (n, a[n], b[n])


GENERAL = [n for n in g.ANGLE_NAMES if n not in ('Hip-shoulder separation', 'Trunk tilt')]
# Separation and trunk tilt refer to a vertical axis, so they are only invariant
# under rotations about that axis; the other angles are invariant under all rotations.


# -------------------------------------------------------------- invariances
def test_rotation_matrix_is_orthogonal():
    q = random_rotation()
    assert np.allclose(q.T @ q, np.eye(3)) and np.isclose(np.linalg.det(q), 1)


def test_translation_scale_rotation_invariance():
    w = skeleton()
    base = g.joint_angles(w)
    for _ in range(20):
        q, s, t = random_rotation(), RNG.uniform(0.3, 3.0), RNG.normal(size=3)
        angles_close(base, g.joint_angles(s * w @ q.T + t), GENERAL)


def test_vertical_axis_rotation_keeps_every_angle():
    w = skeleton()
    th = RNG.uniform(0, 2 * np.pi)
    q = np.array([[np.cos(th), 0, np.sin(th)], [0, 1, 0], [-np.sin(th), 0, np.cos(th)]])
    angles_close(g.joint_angles(w), g.joint_angles(w @ q.T))


def test_reflection_preserves_angles_but_flips_chirality():
    """The EPQ bug: a mirror image has identical joint angles..."""
    w = skeleton()
    m = g.reflect_x(w)
    angles_close(g.joint_angles(w), g.joint_angles(m), GENERAL + ['Trunk tilt'])
    # ...but the signed separation and the triple product both change sign.
    assert abs(g.joint_angles(w)['Hip-shoulder separation']) > 5
    assert np.isclose(g.joint_angles(m)['Hip-shoulder separation'],
                      -g.joint_angles(w)['Hip-shoulder separation'])
    assert g.chirality(m) == -g.chirality(w) != 0


def test_any_improper_orthogonal_map_flips_chirality():
    w = skeleton()
    for _ in range(20):
        q = random_rotation() @ np.diag([1, 1, -1])     # determinant -1
        assert np.isclose(np.linalg.det(q), -1)
        assert g.chirality(w @ q.T) == -g.chirality(w)


def test_rotation_keeps_chirality():
    w = skeleton()
    for _ in range(20):
        assert g.chirality(w @ random_rotation().T) == g.chirality(w)


def test_label_swap_flips_chirality():
    """A left/right mix-up by the pose estimator looks exactly like a reflection."""
    w = skeleton()
    assert g.chirality(g.swap_labels(w)) == -g.chirality(w)


def test_mirror_skeleton_makes_a_valid_body():
    """Reflect + swap labels = a correctly labelled real body of the other
    handedness: chirality is unchanged and mirroring twice is the identity."""
    w = skeleton()
    m = g.mirror_skeleton(w)
    assert g.chirality(m) == g.chirality(w)
    assert np.allclose(g.mirror_skeleton(m), w)
    # The right-hander's hitting arm becomes the mirrored player's left arm...
    a, b = g.joint_angles(w, 'right'), g.joint_angles(m, 'left')
    angles_close(a, b, [n for n in g.ANGLE_NAMES if n != 'Hip-shoulder separation'])
    # ...and a left-hander turns the other way, so the signed separation flips.
    assert abs(a['Hip-shoulder separation']) > 5
    assert np.isclose(b['Hip-shoulder separation'], -a['Hip-shoulder separation'])


# ---------------------------------------------------------------- angle values
def test_straight_and_right_angles():
    assert np.isclose(g.angle([1, 0, 0], [0, 0, 0], [-1, 0, 0]), 180)
    assert np.isclose(g.angle([1, 0, 0], [0, 0, 0], [0, 1, 0]), 90)
    assert np.isnan(g.angle([0, 0, 0], [0, 0, 0], [1, 0, 0]))


def test_signed_horizontal_angle():
    assert np.isclose(abs(g.signed_horizontal_angle([1, 0, 0], [0, 0, 1])), 90)
    assert np.isclose(g.signed_horizontal_angle([1, 0, 0], [0, 0, 1]),
                      -g.signed_horizontal_angle([0, 0, 1], [1, 0, 0]))
    # vertical components are ignored
    assert np.isclose(g.signed_horizontal_angle([1, 5, 0], [1, -3, 0]), 0)


def test_low_visibility_angles_are_dropped():
    vis = np.ones(33)
    vis[g.R_WRIST] = 0.1
    a = g.masked_joint_angles(skeleton(), vis, 'right')
    assert np.isnan(a['Hitting elbow']) and np.isnan(a['Hitting wrist'])
    assert np.isfinite(a['Other elbow'])


# ------------------------------------------------------------- time series
def test_smoothing_reduces_noise():
    t = np.linspace(0, 2 * np.pi, 120)
    clean = np.sin(t)
    noisy = clean + RNG.normal(scale=0.1, size=t.size)
    assert np.mean((g.smooth(noisy, 9, 2) - clean) ** 2) < 0.5 * np.mean((noisy - clean) ** 2)


def test_savgol_preserves_quadratics():
    x = np.arange(30.0) ** 2
    assert np.allclose(g.smooth(x, 7, 2)[3:-3], x[3:-3])


def test_interpolation_fills_short_gaps_only():
    x = np.array([0, np.nan, 2, 3, np.nan, np.nan, np.nan, np.nan, 8])
    y = g.interpolate_nans(x, max_gap=2)
    assert y[1] == 1 and np.isnan(y[5])


def test_contact_and_hitting_arm_detection():
    fps, T = 30, 60
    seq = np.repeat(skeleton()[None], T, axis=0)
    swing = np.exp(-((np.arange(T) - 37) / 4.0) ** 2)      # fast at frame 37
    seq[:, g.L_WRIST, 0] += np.cumsum(swing) * 0.05
    assert g.detect_hitting_arm(seq, fps) == 'left'
    assert abs(g.detect_contact(seq, fps, 'left') - 37) <= 1


def test_dtw_recovers_a_time_warp():
    t = np.linspace(0, 1, 50)
    a = np.sin(2 * np.pi * t)[:, None]
    warped_t = t ** 1.6                                      # same motion, different timing
    b = np.sin(2 * np.pi * warped_t)[:, None]
    cost_warped, path = g.dtw(a, b, band=0.5)
    shifted = np.sin(2 * np.pi * t + 1.0)[:, None]
    cost_different, _ = g.dtw(a, shifted, band=0.5)
    assert path[0] == (0, 0) and path[-1] == (49, 49)
    assert cost_warped < cost_different
    assert all(i2 >= i1 and j2 >= j1 for (i1, j1), (i2, j2) in zip(path, path[1:]))


def test_dtw_of_identical_sequences_is_zero():
    a = RNG.normal(size=(25, 3))
    cost, path = g.dtw(a, a)
    assert cost == 0 and path == [(i, i) for i in range(25)]


if __name__ == '__main__':
    tests = [v for k, v in sorted(globals().items()) if k.startswith('test_')]
    for fn in tests:
        fn()
        print('PASS', fn.__name__)
    print(f'All {len(tests)} tests passed.')
